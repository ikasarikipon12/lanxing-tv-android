﻿package com.cyj265.iptvplayer

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cyj265.iptvplayer.data.Channel
import com.cyj265.iptvplayer.data.EpgParser
import com.cyj265.iptvplayer.data.EpgProgram
import com.cyj265.iptvplayer.data.HttpLoader
import com.cyj265.iptvplayer.data.LanRemoteServer
import com.cyj265.iptvplayer.data.PlaylistParser
import com.cyj265.iptvplayer.data.PlaylistRepository
import com.cyj265.iptvplayer.data.SourceHealthChecker
import com.cyj265.iptvplayer.databinding.ActivityMainBinding
import com.cyj265.iptvplayer.player.PlaybackManager
import com.cyj265.iptvplayer.ui.ChannelAdapter
import com.cyj265.iptvplayer.ui.EpgListAdapter
import com.cyj265.iptvplayer.util.QrCodeUtil
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 主界面：全屏播放 + 悬浮频道列表（OK 唤出，二级分组 + 源切换）+ 右侧设置面板（菜单键唤出）。
 * 遥控器：上下键换台、OK 频道列表、菜单键设置、CH+/CH- 换台。
 *
 * v1.7.1：
 * - 频道同名多源自动合并为一条（如本地列表 CCTV1综合 ×7），播放失败/超时自动切换线路，
 *   播放界面底部"换源"按钮手动切换，设置-线路选择同步切换；
 * - 超时换源：线路起播超时秒数可选 5/10/15/20/25/30/60（默认 10），超时自动切下一条线路；
 * - 偏好设置：显示时间 / 显示网速 / 换台反转 / 跨选分类；
 * - 退出直播：结束全部进程，不再有后台声音；
 * - EPG 节目指南支持每行一个、多个地址，全部加载合并；
 * - 删除自动修复链（不再免重启强修 mediaserver），解码异常仅提示重启机顶盒；
 * - 崩溃日志导出入口同时放在 调试 与 关于 分区。
 * 注意：播放/解码路径（Media3 配置、三档解码策略）继续冻结，不再改动。
 */
class MainActivity : AppCompatActivity(), PlaybackManager.Listener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: PlaylistRepository
    private val sourceHealthChecker = SourceHealthChecker()
    private lateinit var playback: PlaybackManager
    private lateinit var adapter: ChannelAdapter
    private val epgListAdapter = EpgListAdapter()
    private var remoteServer: LanRemoteServer? = null

    private var allChannels: List<Channel> = emptyList()
    private lateinit var groupAdapter: GroupAdapter
    private var currentGroup: String? = null  // null = 全部频道
    /** 分组选中后待定位的频道行位置（右键进频道列表时使用） */
    private var pendingChannelScrollPos = -1
    private var lastBackPressTime: Long = 0
    /** 上次自动检查更新的时间戳（12 小时节流，防 GitHub API 限流） */
    private var lastUpdateCheckAt: Long = 0
    private var autoUpdateCheck: Boolean = true
    private var favorites: MutableSet<String> = HashSet()
    private var showFavoritesOnly = false
    private var currentChannel: Channel? = null
    /** 频道列表中当前获得焦点的频道（用于"收藏当前焦点频道"） */
    private var lastFocusedChannel: Channel? = null
    private var epgPrograms: Map<String, List<EpgProgram>> = emptyMap()
    /** EPG 加载状态：区分"未配置/加载中/就绪/失败"四种提示 */
    private enum class EpgLoadState { NOT_CONFIGURED, LOADING, READY, FAILED }
    private var epgLoadState = EpgLoadState.NOT_CONFIGURED
    private var epgLoadedCount = 0
    /** 复用时间格式化器，避免 EPG 刷新时每频道 new 两次 SimpleDateFormat（GC 压力） */
    private val epgTimeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var lastEpgAttemptAt = 0L
    /** EPG 加载在途标志：防止启动加载、定时刷新、手动刷新同时起多个线程 */
    @Volatile private var epgLoadInFlight = false

    private var videoW = 0
    private var videoH = 0
    private var currentSettingsTab = 0

    // 覆盖层自动隐藏：4 秒无操作淡出顶部信息条与底部控制条
    private val overlayHandler = Handler(Looper.getMainLooper())
    private val overlayHideRunnable = Runnable { hideOverlay() }

    // 右上角时钟 + 每秒刷新网速显示，并每分钟刷新一次列表 EPG 节目文本
    private val clockHandler = Handler(Looper.getMainLooper())
    // ---------- 定时关机 ----------
    private val sleepTimerHandler = Handler(Looper.getMainLooper())
    private val sleepTimerRunnable = Runnable {
        // 定时关机时间到：退出 App
        Toast.makeText(applicationContext, "定时关机时间到，即将退出", Toast.LENGTH_SHORT).show()
        sleepTimerHandler.postDelayed({ finishAndRemoveTask() }, 1500)
    }
    private var sleepTimerEndTime: Long = 0
    private var clockTick = 0
    private val clockRunnable = object : Runnable {
        override fun run() {
            try {
                val sb = StringBuilder(
                    SimpleDateFormat("yyyy/MM/dd\nHH:mm:ss", Locale.getDefault()).format(Date())
                )
                if (repository.showSpeed) {
                    val kbps = playback.bandwidthKbps()
                    if (kbps > 0) sb.append("\n网速 ").append(kbps / 1000.0).append(" Mbps")
                }
                binding.tvClock.text = sb.toString()
                clockTick++
                // 每秒更新 EPG 进度条（只更新进度，不更新文字）
                updateEpgProgressOnly()
                if (clockTick % 300 == 0 && epgPrograms.isNotEmpty()) {
                    adapter.epgNow = buildEpgNowMap()
                    adapter.epgNext = buildEpgNextMap()
                    updateProgramInfo()
                }
                // 每 5 分钟检查一次节目单是否过期（盒子常年不关机，节目单不能停在开机那一刻）
                if (clockTick % 300 == 0) {
                    maybeRefreshEpg()
                }
            } catch (ignored: Throwable) {
            }
            clockHandler.postDelayed(this, 1000L)
        }
    }

    private val openDocument =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { importLocalFile(it) }
        }

    private val createLogDoc =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            uri?.let { exportCrashLogTo(it) }
        }

    private val createBackupDoc =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) {
                writeBackupTo(uri)
            } else {
                Toast.makeText(applicationContext, "未另存到其他位置（备份仍在应用目录）", Toast.LENGTH_SHORT).show()
            }
        }

    private val openRestoreDoc =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                restoreFrom(uri)
            } else {
                Toast.makeText(applicationContext, "已取消恢复", Toast.LENGTH_SHORT).show()
            }
        }

    /** 等待授权「安装未知应用」期间暂存的安装包 */
    private var pendingInstallApk: File? = null

    /** 从系统授权页返回：已授权则继续拉起安装器 */
    private val installPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            val apk = pendingInstallApk
            pendingInstallApk = null
            if (apk != null && apk.exists() && canInstallPackages()) {
                launchInstaller(apk)
            } else if (apk != null && apk.exists()) {
                Toast.makeText(applicationContext, "还没有开启安装授权，无法更新", Toast.LENGTH_LONG).show()
            }
        }

    /** 开启「开机自启」时顺带申请通知权限（Android 13+ 开机通知兜底需要） */
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT < 33) return
        try {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        } catch (ignored: Throwable) {
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 清掉开机时的提醒通知（应用已被用户打开）
        try {
            (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager)
                .cancel(BootReceiver.NOTIFICATION_ID)
        } catch (ignored: Throwable) {
        }
        installCrashHandler()
        try {
            initApp()
        } catch (t: Throwable) {
            reportStartupCrash(t)
        }
    }

    /** 启动主体：任何异常都会走 reportStartupCrash 弹窗显示，不再静默闪退。 */
    private fun initApp() {
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        repository = PlaylistRepository(this)
        favorites = repository.getFavorites().toMutableSet()

        playback = PlaybackManager(this, this)
        playback.attach(binding.playerView)
        playback.setAspectRatio(repository.aspectRatio)
        playback.setSourceTimeoutMs(repository.switchTimeoutSec * 1000L)

        // v1.14.3：禁用启动时解码器健康检测。
        // 根因：启动时后台线程创建 HEVC 解码器实例，和主线程 resumeLastChannel()
        // 播放器初始化冲突，导致 OMX 服务状态异常，第一次启动解码器 init 失败黑屏。
        // 播放失败时 onPlayerError 中已会调用 DecoderHealthCheck 检测，启动时无需重复检测。
        // checkDecoderHealthOnStart()

        adapter = ChannelAdapter(
            onChannelClick = { channel -> onChannelClick(channel) },
            onCollapsedChanged = { groups -> repository.saveCollapsedGroups(groups) },
            onChannelFocused = { ch ->
                lastFocusedChannel = ch
                updateProgramInfo(ch)
                // 换台预加载：焦点频道预热 DNS+TCP，OK 键播放时省握手时间
                playback.preloadChannel(ch.sources.ifEmpty { listOf(ch.url) })
                // 焦点移动只更新节目信息，不自动换台（OK 键才播放）
                // 同步工具条"收藏"按钮的选中态（跟随当前焦点频道）
                updateFavoriteIcon()
            }
        )
        adapter.favorites = favorites
        // 从未手动折叠过时默认全部收起（二级分组体验）
        adapter.setDefaultCollapsed(!repository.hasCollapsedPrefs())
        adapter.setCollapsedGroups(repository.getCollapsedGroups())
        binding.channelList.layoutManager = LinearLayoutManager(this)
        binding.channelList.adapter = adapter
        // 第三栏：今日节目单列表
        binding.epgListView.layoutManager = LinearLayoutManager(this)
        binding.epgListView.adapter = epgListAdapter
        // 双栏模式：右侧纯频道列表（带序号），不显示分组头
        adapter.showGroupHeaders = false

        // 左侧分组列表
        groupAdapter = GroupAdapter(
            onGroupClick = { _ ->
                // 分组上按 OK：直接进入频道列表（分组已在焦点移动时切换）
                binding.channelList.requestFocus()
            },
            onGroupFocused = { group ->
                // 焦点移动到分组即切换右侧频道列表（不抢焦点、不换台）
                // 注意：不能调用 groupAdapter.setSelected()，否则 notifyDataSetChanged 会重置焦点导致跳位/卡死
                currentGroup = group
                rememberLastGroup(group ?: "")
                applyFilter()
                // 记录目标位置，右键进入右栏时才定位
                val targetPos = currentChannel
                    ?.let { adapter.positionOfChannel(it.id) }
                    ?.takeIf { it >= 0 }
                    ?: adapter.firstPositionOfGroup(group ?: "")
                pendingChannelScrollPos = targetPos
                if (targetPos >= 0) {
                    adapter.channelAt(targetPos)?.let { updateProgramInfo(it) }
                }
            }
        )
        binding.groupList.layoutManager = LinearLayoutManager(this)
        binding.groupList.adapter = groupAdapter

        setupSearch()
        setupButtons()
        setupSettingsPanel()
        // 恢复定时关机（如果之前设置了且 App 被重启）
        if (repository.sleepTimerMinutes > 0) {
            startSleepTimer(repository.sleepTimerMinutes)
        }
        setupSourceBar()
        startRemoteServer()

        // 启动：先显示缓存，再尝试刷新
        val cached = repository.loadLocalChannels() ?: repository.loadCachedChannels(
            repository.getActiveSource().orEmpty()
        )
        if (!cached.isNullOrEmpty()) {
            onChannelsLoaded(cached)
        }
        if (!repository.getActiveSource().isNullOrEmpty()) {
            reloadPlaylist()
        }
        loadEpgIfConfigured()

        // 自动恢复上次频道（v1.14.5：等待 SurfaceView 的 surfaceCreated 回调后再播放，
        // 避免启动时视频解码器init成功但渲染到未就绪Surface导致黑屏有声音+native崩溃闪退）
        if (repository.autoResume) {
            waitForSurfaceAndResume()
        }

        // 恢复上次分组
        try {
            if (rememberGroupPrefs().getBoolean("remember_group", false)) {
                val lastGroup = rememberGroupPrefs().getString("last_group", null)
                if (lastGroup != null && allChannels.any { it.group == lastGroup }) {
                    currentGroup = lastGroup
                    groupAdapter.setSelected(lastGroup)
                    applyFilter()
                }
            }
        } catch (ignored: Throwable) {
        }

        // 启动时显示覆盖层，随后自动淡出
        showOverlay()
        updateSourceBar()
        updateSourceStatus()
        updateClockVisibility()

        // 启动自动检查更新（可在设置-关于里开关）
        autoUpdateCheck = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("auto_update_check", true)
        if (autoUpdateCheck) {
            lastUpdateCheckAt =
                getSharedPreferences("settings", MODE_PRIVATE).getLong("last_update_check", 0L)
            checkUpdateSilent()
        }
    }

    /** 启动失败：记录日志并弹窗显示堆栈。 */
    private fun reportStartupCrash(t: Throwable) {
        try {
            val sw = StringWriter()
            t.printStackTrace(PrintWriter(sw))
            crashFile().writeText(
                "startup=" + System.currentTimeMillis() + "\n" + sw.toString(),
                Charsets.UTF_8
            )
        } catch (ignored: Exception) {
        }
        try {
            AlertDialog.Builder(this)
                .setTitle("启动失败（已记录日志）")
                .setMessage(
                    "请把此弹窗截图发给开发者，或在设置→调试中查看完整日志：\n\n" +
                        Log.getStackTraceString(t)
                )
                .setPositiveButton("知道了", null)
                .setCancelable(false)
                .show()
        } catch (ignored: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        clockHandler.post(clockRunnable)
        // 切后台再回来时，如果播放器已就绪但被暂停，恢复播放（避免重新初始化）
        try {
            playback.resumeIfPaused()
        } catch (ignored: Throwable) {
        }
    }

    override fun onPause() {
        clockHandler.removeCallbacks(clockRunnable)
        super.onPause()
    }

    /**
     * 离开前台时停止解码：只暂停、保留播放器实例（重新初始化解码器在老盒子上
     * 会触发黑屏，见 PlaybackManager.pauseForBackground 注释）。回前台由 onResume 续播。
     */
    override fun onStop() {
        try {
            playback.pauseForBackground()
        } catch (ignored: Throwable) {
        }
        super.onStop()
    }

    // ---------- 运行日志（启动/播放/问题定位用） ----------

    private fun crashFile(): File = File(filesDir, "app.log")

    private fun installCrashHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                crashFile().writeText(
                    "time=" + System.currentTimeMillis() + "\nthread=" + thread.name +
                        "\n" + sw.toString(),
                    Charsets.UTF_8
                )
                // 新崩溃：重置"已提示"标志，下次启动会再次提示
                getSharedPreferences("settings", MODE_PRIVATE)
                    .edit().putBoolean("crash_prompted", false).apply()
            } catch (ignored: Exception) {
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    /** 启动自检：后台探测 HEVC 硬解解码器好坏（不阻塞 UI，仅提示不修复）。 */
    private fun checkDecoderHealthOnStart() {
        Thread {
            val healthy = com.cyj265.iptvplayer.player.DecoderHealthCheck.isHardwareHevcHealthy()
            Handler(Looper.getMainLooper()).post {
                if (!healthy && !isFinishing) {
                    Toast.makeText(
                        applicationContext,
                        "检测到硬解解码器异常：如播放黑屏/无声，请重启机顶盒",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun showLastCrashIfAny() {
        val f = crashFile()
        if (!f.exists()) return
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        // 每条新崩溃只提示一次：日志保留，供调试区导出/清除
        if (prefs.getBoolean("crash_prompted", false)) return
        val log = try {
            f.readText(Charsets.UTF_8)
        } catch (e: Exception) {
            return
        }
        prefs.edit().putBoolean("crash_prompted", true).apply()
        val brief = log.lineSequence().take(6).joinToString("\n")
        runOnUiThread {
            Toast.makeText(
                applicationContext,
                "运行日志（可在 设置-调试 中导出）：\n$brief",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ---------- 退出（结束全部进程） ----------

    private fun confirmExit() {
        try {
            AlertDialog.Builder(this)
                .setTitle(R.string.nav_exit)
                .setMessage(R.string.exit_confirm)
                .setPositiveButton(R.string.nav_exit) { _, _ -> exitApp() }
                .setNegativeButton(R.string.close, null)
                .show()
        } catch (ignored: Throwable) {
            exitApp()
        }
    }

    private fun exitApp() {
        overlayHandler.removeCallbacksAndMessages(null)
        clockHandler.removeCallbacksAndMessages(null)
        try {
            remoteServer?.stop()
        } catch (ignored: Exception) {
        }
        try {
            try { sourceHealthChecker.shutdown() } catch (ignored: Throwable) {}
        playback.release()
        } catch (ignored: Exception) {
        }
        try {
            finishAffinity()
        } catch (ignored: Exception) {
        }
        try {
            Process.killProcess(Process.myPid())
        } catch (ignored: Exception) {
        }
        try {
            System.exit(0)
        } catch (ignored: Exception) {
        }
    }

    // ---------- 覆盖层自动隐藏 ----------

    private fun showOverlay() {
        overlayHandler.removeCallbacks(overlayHideRunnable)
        val bar = binding.nowPlayingBar
        if (bar.visibility != View.VISIBLE) {
            bar.visibility = View.VISIBLE
            bar.animate().cancel()
            bar.alpha = 0f
            bar.animate().alpha(1f).setDuration(200).start()
        }
        overlayHandler.removeCallbacks(overlayHideRunnable)
        if (repository.autoHideOverlay) {
            overlayHandler.postDelayed(overlayHideRunnable, 4000L)
        }
    }

    private fun hideOverlay() {
        val bar = binding.nowPlayingBar
        if (bar.visibility == View.VISIBLE) {
            bar.animate().cancel()
            bar.animate().alpha(0f).setDuration(300)
                .withEndAction { bar.visibility = View.GONE }
        }
    }

    // ---------- 面板显隐 ----------

    private val isChannelPanelVisible: Boolean
        get() = binding.channelPanel.visibility == View.VISIBLE

    private val isSettingsPanelVisible: Boolean
        get() = binding.settingsPanel.visibility == View.VISIBLE

    private fun showChannelPanel() {
        overlayHandler.removeCallbacks(overlayHideRunnable)
        binding.settingsPanel.visibility = View.GONE
        binding.channelPanel.visibility = View.VISIBLE
        binding.channelPanel.alpha = 0f
        binding.channelPanel.animate().alpha(1f).setDuration(160).start()
        updateSourceBar()
        updateProgramInfo()
        // 若 EPG 已配置但之前加载失败，打开列表时自动重试（网络恢复后无需重启）
        if (epgLoadState == EpgLoadState.FAILED && repository.getEpgUrls().isNotEmpty()) {
            loadEpgIfConfigured()
        }
        // 默认焦点到左侧分组列表的当前分组
        currentChannel?.group?.let { g ->
            if (currentGroup != g) {
                currentGroup = g
                groupAdapter.setSelected(g)
                applyFilter()
            }
        }
        val groupPos = groupAdapter.positionOfGroup(currentGroup)
        if (groupPos >= 0) {
            binding.groupList.scrollToPosition(groupPos)
        }
        // 记录右栏目标位置（当前播放频道或分组第一个）
        val curPos = currentChannel?.let { adapter.positionOfChannel(it.id) } ?: -1
        pendingChannelScrollPos = if (curPos >= 0) curPos else adapter.firstPositionOfGroup(currentGroup ?: "")
        // 打开面板就立即把右栏滚动到当前频道（之前必须再按一次右键才定位）
        scrollChannelListTo(pendingChannelScrollPos)
        binding.groupList.post {
            if (groupPos >= 0) {
                val holder = binding.groupList.findViewHolderForAdapterPosition(groupPos)
                holder?.itemView?.requestFocus()
            }
            if (!binding.groupList.hasFocus()) binding.groupList.requestFocus()
        }
    }

    /**
     * 把右栏频道列表滚动到指定行并居中。
     * scrollToPosition 只做一次请求、不会立即布局，所以先滚动再延迟一帧用
     * scrollToPositionWithOffset 兜底，保证该行真正可见（findViewHolder 才拿得到）。
     */
    private fun scrollChannelListTo(pos: Int) {
        if (pos < 0) return
        try {
            binding.channelList.scrollToPosition(pos)
            binding.channelList.post {
                val lm = binding.channelList.layoutManager as? LinearLayoutManager ?: return@post
                // 把目标行放在可视区上部 1/3 处，既不贴顶也能看到上下文
                lm.scrollToPositionWithOffset(pos, (binding.channelList.height / 3).coerceAtLeast(0))
            }
        } catch (ignored: Throwable) {
        }
    }

    private fun hideChannelPanel() {
        binding.channelPanel.visibility = View.GONE
        showOverlay()
    }

    private fun showSettingsPanel() {
        overlayHandler.removeCallbacks(overlayHideRunnable)
        binding.channelPanel.visibility = View.GONE
        binding.settingsPanel.visibility = View.VISIBLE
        binding.settingsPanel.alpha = 0f
        binding.settingsPanel.animate().alpha(1f).setDuration(160).start()
        refreshSettingsSourceInput()
        updateCurrentSourceLabel()
        updateSourceStatus()
        refreshCrashLog()
        updateSourceOptions()
        updateTimeoutSelection()
        updateDecoderSelection()
        updateAspectRatioSelection()
        // 焦点默认落在导航列当前项（上下键切换分区）；延迟到面板布局完成后，
        // 避免 updateSourceOptions() 重建直播源列表导致焦点被抢进二级菜单。
        val navs = settingsNavs()
        // 上次停在「退出」分区时，下次打开回到第一个分区（避免一进设置就落在退出项上）
        if (currentSettingsTab == navs.lastIndex) selectSettingsTab(0)
        val navIdx = currentSettingsTab.coerceIn(0, navs.size - 1)
        binding.settingsPanel.post { navs[navIdx].requestFocus() }
    }

    private fun hideSettingsPanel() {
        binding.settingsPanel.visibility = View.GONE
        showOverlay()
    }

    // ---------- UI 初始化 ----------

    private fun setupSearch() {
        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
    }

    private fun setupButtons() {
        binding.btnPanelSettings.setOnClickListener { showSettingsPanel() }
        binding.btnFavorites.setOnClickListener {
            showFavoritesOnly = !showFavoritesOnly
            applyFilter()
            binding.tvStatus.text =
                if (showFavoritesOnly) getString(R.string.favorites) else getString(R.string.channel_list)
            updateFavoriteIcon()
        }
        // 频道列表工具条：对当前焦点频道（无焦点时为正在播放频道）收藏/取消收藏
        binding.btnFavoriteFocused.setOnClickListener { toggleFavoriteFocused() }
    }

    // ---------- 线路选择 ----------

    /** 手动切换当前频道下一条线路（多线路频道有效） */
    private fun switchToNextLine() {
        val switched = playback.switchToNextLine()
        if (!switched) {
            Toast.makeText(applicationContext, "当前频道只有 1 条线路", Toast.LENGTH_SHORT).show()
            return
        }
        updateNowPlaying()
    }

    /** 手动切换当前频道上一条线路（多线路频道有效） */
    private fun switchToPrevLine() {
        val switched = playback.switchToPrevLine()
        if (!switched) {
            Toast.makeText(applicationContext, "当前频道只有 1 条线路", Toast.LENGTH_SHORT).show()
            return
        }
        updateNowPlaying()
    }

    // ---------- 直播源切换条（频道列表顶部） ----------

    private fun setupSourceBar() {
        binding.tvSourceBar.setOnClickListener { switchToNextSource() }
    }

    /** 设置面板：动态渲染直播源切换列表（当前源高亮，点击切换，右侧删除） */
    private fun updateSourceOptions() {
        try {
            binding.sourceListContainer.removeAllViews()
            val sources = repository.getSources()
            if (sources.isEmpty()) {
                val tv = TextView(this).apply {
                    text = "暂无直播源，请在下方添加（长按可删除）"
                    setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_secondary))
                    textSize = 13f
                    setPadding(16, 12, 8, 12)
                }
                binding.sourceListContainer.addView(tv)
                return
            }
            val active = repository.activeSourceIndex
            sources.forEachIndexed { i, url ->
                // 每行：横向 LinearLayout（左侧源信息可点击切换 + 右侧删除按钮）
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    setPadding(0, 4, 0, 4)
                }
                val health = repository.getSourceHealth(url)
                val healthStr = when (health.status) {
                    SourceHealthChecker.SourceHealth.Status.GOOD -> "●正常 ${health.latencyMs}ms"
                    SourceHealthChecker.SourceHealth.Status.SLOW -> "●较慢 ${health.latencyMs}ms"
                    SourceHealthChecker.SourceHealth.Status.UNAVAILABLE -> "●不可用"
                    SourceHealthChecker.SourceHealth.Status.UNTESTED -> "○未检测"
                }
                val info = TextView(this).apply {
                    text = (if (i == active) "▶ " else "○ ") + "源 " + (i + 1) + "/" + sources.size +
                        "  ·  " + sourceLabel(url) + "\n  " + healthStr
                    textSize = 14f
                    setPadding(16, 14, 8, 14)
                    isFocusable = true
                    isClickable = true
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    if (i == active) {
                        setTextColor(ContextCompat.getColor(this@MainActivity, R.color.accent))
                        setTypeface(typeface, Typeface.BOLD)
                        setBackgroundColor(0x2FFFFFFF.toInt())
                    } else {
                        setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
                    }
                    // 焦点样式：亮蓝背景 + 白字加粗（和频道列表统一）
                    onFocusChangeListener = View.OnFocusChangeListener { _, focused ->
                        if (focused) {
                            setBackgroundColor(0xFF3D8BFF.toInt())
                            setTextColor(0xFFFFFFFF.toInt())
                            setTypeface(typeface, Typeface.BOLD)
                        } else {
                            if (i == active) {
                                setBackgroundColor(0x2FFFFFFF.toInt())
                                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.accent))
                                setTypeface(typeface, Typeface.BOLD)
                            } else {
                                setBackgroundColor(0x00000000)
                                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
                                setTypeface(typeface, Typeface.NORMAL)
                            }
                        }
                    }
                }
                info.setOnClickListener {
                    if (i != repository.activeSourceIndex) {
                        repository.activeSourceIndex = i
                        currentChannel = null
                        adapter.setSelected(null)
                        refreshSourceUI()
                        reloadPlaylist(true)
                        Toast.makeText(
                            applicationContext,
                            getString(R.string.switch_source) + "：源 " + (i + 1),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                // 长按删除（遥控器长按 OK 键）
                info.setOnLongClickListener {
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("删除直播源")
                        .setMessage("确定删除源 " + (i + 1) + "（" + sourceLabel(url) + "）吗？")
                        .setPositiveButton("删除") { _, _ -> deleteSource(i) }
                        .setNegativeButton("取消", null)
                        .show()
                    true
                }
                row.addView(info)
                binding.sourceListContainer.addView(row)
            }
        } catch (ignored: Throwable) {
        }
    }

    private fun switchToNextSource() {
        val next = repository.switchToNextSource()
        if (next == null) {
            Toast.makeText(applicationContext, "未配置直播源，请在设置中添加", Toast.LENGTH_SHORT).show()
            return
        }
        currentChannel = null
        adapter.setSelected(null)
        updateSourceBar()
        updateSourceStatus()
        reloadPlaylist(true)
        Toast.makeText(
            applicationContext,
            getString(R.string.switch_source) + "：" + sourceLabel(next),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun switchToPrevSource() {
        val prev = repository.switchToPrevSource()
        if (prev == null) {
            Toast.makeText(applicationContext, "未配置直播源，请在设置中添加", Toast.LENGTH_SHORT).show()
            return
        }
        currentChannel = null
        adapter.setSelected(null)
        updateSourceBar()
        updateSourceStatus()
        reloadPlaylist(true)
        Toast.makeText(
            applicationContext,
            getString(R.string.switch_source) + "：" + sourceLabel(prev),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun updateSourceBar() {
        val sources = repository.getSources()
        binding.tvSourceBar.text = if (sources.isEmpty()) {
            getString(R.string.nav_source) + "：未配置（OK 进设置添加）"
        } else {
            "直播源 " + (repository.activeSourceIndex + 1) + "/" + sources.size +
                " · " + sourceLabel(repository.getActiveSource() ?: "") + "  ·  OK 切换"
        }
    }

    private fun sourceLabel(url: String): String {
        return try {
            val u = Uri.parse(url)
            val name = u.path?.substringAfterLast('/')?.substringBeforeLast('.') ?: ""
            if (name.isNotBlank() && name.length <= 24) name else (u.host ?: url)
        } catch (e: Exception) {
            url
        }
    }

    // ---------- 扫码局域网管理 ----------

    /** 局域网管理页访问令牌：首次生成后固定，二维码里带上它，同网未扫码的设备无法操作。 */
    private fun lanToken(): String {
        val sp = getSharedPreferences("settings", MODE_PRIVATE)
        var t = sp.getString("lan_token", null)
        if (t.isNullOrEmpty()) {
            t = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 10)
            sp.edit().putString("lan_token", t).apply()
        }
        return t
    }

    private fun startRemoteServer() {
        remoteServer = LanRemoteServer(
            onSave = { sources, epg -> handleRemoteSave(sources, epg) },
            onPlayDirect = { url ->
                runOnUiThread {
                    try {
                        playDirect(url, url)
                    } catch (ignored: Throwable) {
                    }
                }
            },
            getStateJson = { stateJson() },
            token = lanToken()
        )
        try {
            remoteServer?.start()
        } catch (e: Exception) {
            remoteServer = null
        }
    }

    private fun handleRemoteSave(sources: List<String>, epg: String?) {
        runOnUiThread {
            try {
                repository.saveSources(sources)
                if (epg != null) {
                    repository.setEpgUrls(
                        epg.split("\n", "\r\n").map { it.trim() }.filter { it.isNotEmpty() }
                    )
                }
                refreshSettingsSourceInput()
                refreshEpgUrlDisplay()
                currentChannel = null
                adapter.setSelected(null)
                updateSourceBar()
                updateSourceStatus()
                updateSourceOptions()
                reloadPlaylist(true)
                loadEpgIfConfigured()
                Toast.makeText(
                    applicationContext,
                    "手机已保存 " + sources.size + " 个直播源，正在刷新…",
                    Toast.LENGTH_LONG
                ).show()
            } catch (ignored: Throwable) {
            }
        }
    }

    private fun stateJson(): String {
        return try {
            JSONObject()
                .put("sources", JSONArray(repository.getSources()))
                .put("active", repository.activeSourceIndex)
                .put("epg", repository.getEpgUrls().joinToString("\n"))
                .put("epgCount", repository.epgProgramCount)
                .toString()
        } catch (e: Exception) {
            "{}"
        }
    }

    /** 弹出添加直播源对话框（替代布局内 EditText，遥控器更易操作） */
    private fun showAddSourceDialog() {
        val et = android.widget.EditText(this).apply {
            hint = "https://example.com/list.m3u"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF999999.toInt())
            setPadding(40, 30, 40, 30)
            setBackgroundColor(0xFF1A1A2E.toInt())
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("添加直播源")
            .setMessage("输入 M3U/TXT 播放列表 URL（每行一个，支持多个）")
            .setView(et)
            .setPositiveButton("添加") { _, _ ->
                val url = et.text.toString().trim()
                if (url.isNotEmpty()) {
                    addSourceFromText(url)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    /** 从文本添加源（支持多行 URL），供弹窗调用 */
    private fun addSourceFromText(text: String) {
        val urls = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (urls.isEmpty()) {
            Toast.makeText(applicationContext, "请输入有效的 URL", Toast.LENGTH_SHORT).show()
            return
        }
        urls.forEach { repository.addSource(it) }
        refreshSourceUI()
        refreshSettingsSourceInput()
        updateSourceOptions()
        reloadPlaylist(true)
        Toast.makeText(applicationContext, "已添加 ${urls.size} 个直播源", Toast.LENGTH_SHORT).show()
    }

    /** 弹出节目单地址编辑对话框 */
    private fun showEpgUrlDialog() {
        val current = repository.getEpgUrls().joinToString("\n")
        val et = android.widget.EditText(this).apply {
            hint = "https://example.com/epg.xml（可选，每行一个）"
            setText(current)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF999999.toInt())
            setPadding(40, 30, 40, 30)
            setBackgroundColor(0xFF1A1A2E.toInt())
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("节目单地址（EPG）")
            .setMessage("输入 EPG XML/XML.GZ 地址（可选，每行一个，自动降级）")
            .setView(et)
            .setPositiveButton("保存并加载") { _, _ ->
                val text = et.text.toString().trim()
                val urls = if (text.isEmpty()) emptyList() else text.lines().map { it.trim() }.filter { it.isNotEmpty() }
                repository.setEpgUrls(urls)
                refreshSettingsSourceInput()
                if (urls.isNotEmpty()) {
                    loadEpgIfConfigured()
                    Toast.makeText(applicationContext, "节目单已保存，正在加载...", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(applicationContext, "已清除节目单地址", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    /** 节目单分类的控件初始化与监听器 */
    private fun setupEpgSettings() {
        // 显示当前 EPG URL
        refreshEpgUrlDisplay()
        // 启用开关
        updateEpgEnabledUI()
        binding.tvEpgEnabled.setOnClickListener {
            repository.epgEnabled = !repository.epgEnabled
            updateEpgEnabledUI()
            if (repository.epgEnabled) loadEpgIfConfigured()
        }
        // 刷新频率
        updateEpgRefreshUI()
        binding.epgRefresh1h.setOnClickListener { setEpgRefreshHours(1) }
        binding.epgRefresh2h.setOnClickListener { setEpgRefreshHours(2) }
        binding.epgRefreshDaily.setOnClickListener { setEpgRefreshHours(24) }
        // 清除缓存
        binding.btnClearEpgCache.setOnClickListener {
            repository.clearEpgCache()
            Toast.makeText(applicationContext, "节目单缓存已清除", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshEpgUrlDisplay() {
        val urls = repository.getEpgUrls()
        binding.tvEpgUrl.text = if (urls.isEmpty()) "未设置（按 OK 输入）" else urls.joinToString("  |  ")
    }

    private fun updateEpgEnabledUI() {
        if (repository.epgEnabled) {
            binding.tvEpgEnabled.text = "开"
            binding.tvEpgEnabled.setTextColor(0xFF4CAF50.toInt())
        } else {
            binding.tvEpgEnabled.text = "关"
            binding.tvEpgEnabled.setTextColor(0xFF9E9E9E.toInt())
        }
    }

    private fun setEpgRefreshHours(hours: Int) {
        repository.epgRefreshHours = hours
        updateEpgRefreshUI()
        Toast.makeText(applicationContext, "节目单刷新频率：${if (hours >= 24) "每天" else "每${hours}小时"}", Toast.LENGTH_SHORT).show()
    }

    private fun updateEpgRefreshUI() {
        val h = repository.epgRefreshHours
        val activeBg = 0xFF3D8BFF.toInt()
        val activeText = 0xFFFFFFFF.toInt()
        val normalBg = 0x00000000.toInt()
        val normalText = 0xFFCCCCCC.toInt()
        listOf(binding.epgRefresh1h to 1, binding.epgRefresh2h to 2, binding.epgRefreshDaily to 24).forEach { (v, hh) ->
            if (h == hh) {
                v.setBackgroundColor(activeBg)
                v.setTextColor(activeText)
            } else {
                v.setBackgroundColor(normalBg)
                v.setTextColor(normalText)
            }
        }
    }

    private fun showScanDialog() {
        val ip = localIpAddress()
        if (ip == null) {
            Toast.makeText(applicationContext, R.string.scan_no_wifi, Toast.LENGTH_LONG).show()
            return
        }
        val server = remoteServer
        if (server == null) {
            Toast.makeText(applicationContext, R.string.scan_server_off, Toast.LENGTH_LONG).show()
            return
        }
        val url = "http://$ip:19090/?k=${lanToken()}"
        val qr: Bitmap? = try {
            QrCodeUtil.encode(url, 640)
        } catch (e: Throwable) {
            null
        }
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.gravity = android.view.Gravity.CENTER_HORIZONTAL
        content.setPadding(48, 24, 48, 24)
        val qrView = ImageView(this)
        qrView.setPadding(0, 0, 0, 16)
        if (qr != null) {
            qrView.setImageBitmap(qr)
            content.addView(qrView, LinearLayout.LayoutParams(420, 420))
        }
        val tv = android.widget.TextView(this)
        tv.setTextColor(0xFF333333.toInt())
        tv.textSize = 15f
        tv.setLineSpacing(4f, 1f)
        tv.gravity = android.view.Gravity.CENTER_HORIZONTAL
        tv.text = "请用手机（与机顶盒同一 Wi-Fi）扫描：\n$url\n\n可添加/切换直播源、设置节目指南、直接播放"
        content.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(R.string.scan_qr_title)
            .setView(content)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    private fun localIpAddress(): String? {
        try {
            val nis = NetworkInterface.getNetworkInterfaces()
            while (nis.hasMoreElements()) {
                val ni = nis.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        return a.hostAddress
                    }
                }
            }
        } catch (ignored: Exception) {
        }
        return null
    }

    // ---------- 设置面板 ----------

    private fun containsFocus(root: View): Boolean {
        if (root.hasFocus()) return true
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) {
                if (containsFocus(root.getChildAt(i))) return true
            }
        }
        return false
    }

    /** 导航列 ID 集合（单独处理选中样式，不应用通用焦点样式） */
    private val navViewIds = setOf(
        R.id.navLineup, R.id.navEpg, R.id.navRatio, R.id.navDecoder, R.id.navTimeout,
        R.id.navPrefs, R.id.navUpdate, R.id.navDebug, R.id.navBackup, R.id.navAbout, R.id.navExit
    )

    /** 展开式选项 ID 集合（单独管理焦点样式，失焦时恢复选中状态） */
    private val optionViewIds = setOf(
        R.id.timeout5, R.id.timeout10, R.id.timeout15, R.id.timeout20,
        R.id.timeout25, R.id.timeout30, R.id.timeout60,
        R.id.ratiofit, R.id.ratio169, R.id.ratio43, R.id.ratiozoom, R.id.ratiofill,
        R.id.decoderAuto, R.id.decoderHard, R.id.decoderSoft
    )

    /** 给设置面板里所有可聚焦 TextView/Button 统一加焦点样式（亮蓝背景+白字加粗） */
    private fun applySettingsFocusStyles() {
        try {
            fun traverse(view: View) {
                if (view is ViewGroup) {
                    for (i in 0 until view.childCount) {
                        traverse(view.getChildAt(i))
                    }
                    return
                }
                if (view !is TextView) return
                if (view is android.widget.EditText) return  // 输入框保持原样
                if (view.id in navViewIds) {
                    // 导航项焦点态：使用选中态 drawable + 白字加粗 + 切换 tab
                    view.onFocusChangeListener = View.OnFocusChangeListener { _, focused ->
                        if (focused) {
                            // 先切分类（selectSettingsTab 会重刷导航样式），再覆盖成焦点态，
                            // 否则焦点色会被选中态覆盖
                            val navIdx = settingsNavs().indexOf(view)
                            if (navIdx >= 0 && navIdx != currentSettingsTab) {
                                selectSettingsTab(navIdx)
                            }
                            // 焦点用实心亮蓝；「已选中但未聚焦」是半透明蓝底
                            view.setBackgroundResource(R.drawable.bg_item_focused)
                            view.setTextColor(Color.WHITE)
                            view.setTypeface(view.typeface, Typeface.BOLD)
                        } else {
                            // 失焦时恢复：如果是当前选中 tab 则保持选中态，否则恢复普通态
                            val navIndex = settingsNavs().indexOf(view)
                            if (navIndex == currentSettingsTab) {
                                view.setBackgroundResource(R.drawable.bg_nav_item_selected)
                                view.setTextColor(Color.WHITE)
                                view.setTypeface(view.typeface, Typeface.BOLD)
                            } else {
                                view.setBackgroundResource(R.drawable.bg_nav_item)
                                view.setTextColor(0xFFCCCCCC.toInt())
                                view.setTypeface(view.typeface, Typeface.NORMAL)
                            }
                        }
                    }
                    return
                }
                if (view.id in optionViewIds) return  // 展开式选项单独处理（失焦恢复选中状态）
                if (!view.isFocusable) return
                val normalTextColor = view.currentTextColor
                // 记住原背景和 tint（按钮的 backgroundTint、输入行的 bg_search 等），
                // 失焦要还原成原样，否则按钮被焦点“扫”过一次就变成没有底色的纯文字
                val normalBackground = view.background
                val normalTint = view.backgroundTintList
                view.onFocusChangeListener = View.OnFocusChangeListener { _, focused ->
                    if (focused) {
                        // 不清掉 backgroundTint，焦点蓝底会被按钮的 tint 重新染色，看起来只有字变白
                        view.backgroundTintList = null
                        view.setBackgroundResource(R.drawable.bg_item_focused)
                        view.setTextColor(0xFFFFFFFF.toInt())
                        view.setTypeface(view.typeface, Typeface.BOLD)
                    } else {
                        view.background = normalBackground
                        view.backgroundTintList = normalTint
                        view.setTextColor(normalTextColor)
                        view.setTypeface(view.typeface, Typeface.NORMAL)
                    }
                }
            }
            traverse(binding.settingsPanel)
        } catch (ignored: Throwable) {
        }
    }

    /** 给展开式选项（超时/比例/解码）设置焦点样式：焦点亮蓝+白字，失焦调用 refreshFn 恢复选中状态 */
    private fun applyOptionFocus(view: TextView, refreshFn: () -> Unit) {
        view.onFocusChangeListener = View.OnFocusChangeListener { _, focused ->
            if (focused) {
                view.setBackgroundResource(R.drawable.bg_item_focused)
                view.setTextColor(0xFFFFFFFF.toInt())
                view.paint.isFakeBoldText = true
            } else {
                refreshFn()
            }
        }
    }

    private fun rememberGroupPrefs() = getSharedPreferences("settings", MODE_PRIVATE)

    private fun rememberLastGroup(group: String) {
        try {
            if (rememberGroupPrefs().getBoolean("remember_group", false)) {
                rememberGroupPrefs().edit().putString("last_group", group).apply()
            }
        } catch (ignored: Throwable) {
        }
    }

    private fun settingsNavs(): List<View> = listOf(
        binding.navLineup, binding.navEpg, binding.navRatio, binding.navDecoder,
        binding.navTimeout, binding.navPrefs, binding.navUpdate,
        binding.navDebug, binding.navBackup, binding.navAbout, binding.navExit
    )

    private fun settingsSections(): List<View> = listOf(
        binding.sectionLineup, binding.sectionEpg, binding.sectionRatio, binding.sectionDecoder,
        binding.sectionTimeout, binding.sectionPrefs, binding.sectionUpdate,
        binding.sectionDebug, binding.sectionBackup, binding.sectionAbout, binding.sectionExit
    )

    private fun selectSettingsTab(index: Int, focusDetail: Boolean = false) {
        val changed = index != currentSettingsTab
        currentSettingsTab = index
        val navs = settingsNavs()
        val sections = settingsSections()
        sections.forEachIndexed { i, s ->
            s.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        // 换分区时回到顶部，否则会停在上一分区的滚动位置，像内容缺了一截
        if (changed) binding.settingsScroll.scrollTo(0, 0)
        navs.forEachIndexed { i, n ->
            if (i == index) {
                n.setBackgroundResource(R.drawable.bg_nav_item_selected)
                (n as android.widget.TextView).setTextColor(Color.WHITE)
                (n as android.widget.TextView).setTypeface((n as android.widget.TextView).typeface, Typeface.BOLD)
            } else {
                (n as android.widget.TextView).setTypeface((n as android.widget.TextView).typeface, Typeface.NORMAL)
                n.setBackgroundResource(0)
                (n as android.widget.TextView).setTextColor(0xFFCCCCCC.toInt())
            }
        }
        // 默认不抢焦点：焦点保持在导航列（上下键可在各分区间切换）；
        // 只有用户按右键（或主动要求进详情）时才定位到当前选中值。
        if (focusDetail) focusValueInSettingsSection(index)
    }

    /** 切 tab 后把焦点定位到当前选中值（展开式分区）。
     *  延迟到下一次布局再请求焦点：刚由 GONE 变 VISIBLE 的分区里控件还没测量，
     *  立刻 requestFocus 会失败，表现为右键偶尔没反应。 */
    private fun focusValueInSettingsSection(index: Int) {
        val safeIndex = index.coerceIn(0, settingsSections().size - 1)
        binding.settingsPanel.post {
            try {
                val target: View? = when (safeIndex) {
                    1 -> binding.tvEpgUrl
                    2 -> binding.root.findViewById(
                        when (repository.aspectRatio) {
                            "16:9" -> R.id.ratio169
                            "4:3" -> R.id.ratio43
                            "zoom" -> R.id.ratiozoom
                            "fill" -> R.id.ratiofill
                            else -> R.id.ratiofit
                        }
                    )
                    3 -> binding.root.findViewById(
                        when (playback.currentDecoderMode()) {
                            "hardware" -> R.id.decoderHard
                            "software" -> R.id.decoderSoft
                            else -> R.id.decoderAuto
                        }
                    )
                    4 -> binding.root.findViewById(
                        when (repository.switchTimeoutSec) {
                            5 -> R.id.timeout5
                            10 -> R.id.timeout10
                            15 -> R.id.timeout15
                            20 -> R.id.timeout20
                            25 -> R.id.timeout25
                            30 -> R.id.timeout30
                            else -> R.id.timeout60
                        }
                    )
                    7 -> binding.btnClearCrashLog
                    else -> firstFocusableChild(settingsSections()[safeIndex])
                }
                if (target != null && target.isShown && target.requestFocus()) return@post
                // 详情区无可聚焦项：回退到导航列，避免焦点丢失
                val navs = settingsNavs()
                navs[safeIndex.coerceIn(0, navs.size - 1)].requestFocus()
            } catch (ignored: Throwable) {
            }
        }
    }

    /** 当前分区内按屏幕位置排序的可聚焦控件。 */
    private fun orderedFocusables(section: View): List<View> {
        val out = ArrayList<View>()
        fun collect(v: View) {
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) collect(v.getChildAt(i))
            } else if (v.isShown && v.isFocusable && v.isEnabled) {
                out.add(v)
            }
        }
        collect(section)
        if (out.size <= 1) return out
        val loc = Array(out.size) { IntArray(2) }
        out.forEachIndexed { i, v -> v.getLocationOnScreen(loc[i]) }
        return out.withIndex()
            .sortedWith(compareBy({ loc[it.index][1] }, { loc[it.index][0] }))
            .map { it.value }
    }

    /** 详情区焦点在指定方向上是否还有同分区的邻居，用来拦住 FocusFinder 的跨区跳转。 */
    private fun settingsDetailHasNeighbor(horizontal: Boolean, forward: Boolean): Boolean {
        val focused = currentFocus ?: return false
        val sections = settingsSections()
        val section = sections.getOrNull(currentSettingsTab.coerceIn(0, sections.lastIndex)) ?: return false
        if (!containsFocus(section)) return false
        val fLoc = IntArray(2)
        focused.getLocationOnScreen(fLoc)
        val fW = focused.width
        val fH = focused.height
        for (v in orderedFocusables(section)) {
            if (v === focused) continue
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            if (horizontal) {
                val overlapY = minOf(fLoc[1] + fH, loc[1] + v.height) - maxOf(fLoc[1], loc[1])
                if (overlapY <= fH / 3) continue
                if (forward && loc[0] > fLoc[0]) return true
                if (!forward && loc[0] < fLoc[0]) return true
            } else {
                val overlapX = minOf(fLoc[0] + fW, loc[0] + v.width) - maxOf(fLoc[0], loc[0])
                if (overlapX <= fW / 3) continue
                if (forward && loc[1] > fLoc[1]) return true
                if (!forward && loc[1] < fLoc[1]) return true
            }
        }
        return false
    }

    private fun focusSettingsNavCurrent() {
        val navs = settingsNavs()
        navs.getOrNull(currentSettingsTab.coerceIn(0, navs.lastIndex))?.requestFocus()
    }

    /** 深度优先找第一个可聚焦子 View。 */
    private fun firstFocusableChild(parent: View): View? {
        if (parent is ViewGroup) {
            for (i in 0 until parent.childCount) {
                val child = parent.getChildAt(i)
                if (child.isFocusable) return child
                val sub = firstFocusableChild(child)
                if (sub != null) return sub
            }
        }
        return null
    }

    private fun setupSettingsPanel() {
        setupSettingsTabs()
        refreshSettingsSourceInput()

        binding.btnImportFile.setOnClickListener {
            try {
                openDocument.launch(arrayOf("*/*"))
            } catch (e: Exception) {
                Toast.makeText(
                    applicationContext,
                    "无法打开文件选择器（系统无文件管理），请改用播放列表 URL 加载",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        binding.btnRefreshSource.setOnClickListener {
            val url = repository.getActiveSource()
            if (url.isNullOrEmpty()) {
                Toast.makeText(applicationContext, "未配置直播源", Toast.LENGTH_SHORT).show()
            } else {
                currentChannel = null
                adapter.setSelected(null)
                reloadPlaylist(true)
                Toast.makeText(applicationContext, "正在刷新当前源...", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnAddSource.setOnClickListener { showAddSourceDialog() }

        // 一键测速
        binding.btnCheckAllSources.setOnClickListener {
            val sources = repository.getSources()
            if (sources.isEmpty()) {
                Toast.makeText(applicationContext, "暂无直播源", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            binding.btnCheckAllSources.text = "检测中..."
            binding.btnCheckAllSources.isEnabled = false
            sourceHealthChecker.checkAllSources(
                urls = sources,
                timeoutMs = 5000,
                onProgress = { done, total, health ->
                    repository.setSourceHealth(health.url, health)
                    runOnUiThread { updateSourceOptions() }
                },
                onComplete = { results ->
                    runOnUiThread {
                        binding.btnCheckAllSources.text = "一键测速"
                        binding.btnCheckAllSources.isEnabled = true
                        updateSourceOptions()
                        if (repository.autoSelectFastest) {
                            val fastestIdx = sourceHealthChecker.findFastestAvailable(results)
                            if (fastestIdx >= 0 && fastestIdx != repository.activeSourceIndex) {
                                repository.activeSourceIndex = fastestIdx
                                currentChannel = null
                                adapter.setSelected(null)
                                refreshSourceUI()
                                reloadPlaylist(true)
                                Toast.makeText(applicationContext, "已自动切换到最快源（源${fastestIdx + 1}）", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(applicationContext, "测速完成，当前已是最快源", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            val available = results.count { it.available }
                            Toast.makeText(applicationContext, "测速完成：${available}/${results.size} 个源可用", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }

        // 自动优选开关
        updateAutoSelectFastestUI()
        binding.tvAutoSelectFastest.setOnClickListener {
            repository.autoSelectFastest = !repository.autoSelectFastest
            updateAutoSelectFastestUI()
            Toast.makeText(applicationContext, if (repository.autoSelectFastest) "已开启自动优选" else "已关闭自动优选", Toast.LENGTH_SHORT).show()
        }
        binding.tvCurrentSource.setOnClickListener {
            switchToNextSource()
            refreshSourceUI()
            refreshSettingsSourceInput()
        }
        binding.tvEpgUrl.setOnClickListener { showEpgUrlDialog() }
        // 直接播放流地址已移到诊断分类（btnPlayDirect 已从布局移除）
        binding.btnCloseSettings.setOnClickListener { hideSettingsPanel() }
        binding.btnScanManage.setOnClickListener { showScanDialog() }

        // ===== 节目单（EPG）分类 =====
        setupEpgSettings()

        binding.btnClearFavorites.setOnClickListener {
            favorites.clear()
            repository.setFavorites(favorites)
            adapter.favorites = favorites
            refreshFavoriteMarks()
            updateFavoriteIcon()
            updateFavCount()
            Toast.makeText(applicationContext, R.string.cleared, Toast.LENGTH_SHORT).show()
        }

        // 直播源切换列表（多播放列表）
        updateSourceOptions()

        // 超时换源（展开式选项）
        setupTimeoutOptions()
        updateTimeoutSelection()

        // 偏好设置
        binding.chkShowClock.isChecked = repository.showClock
        binding.chkShowClock.setOnCheckedChangeListener { _, checked ->
            repository.showClock = checked
            if (checked) updateClockVisibility()
        }
        binding.chkShowSpeed.isChecked = repository.showSpeed
        binding.chkShowSpeed.setOnCheckedChangeListener { _, checked ->
            repository.showSpeed = checked
        }
        binding.chkReverseZap.isChecked = repository.reverseZap
        binding.chkReverseZap.setOnCheckedChangeListener { _, checked ->
            repository.reverseZap = checked
        }
        binding.chkCrossCategory.isChecked = repository.crossCategory
        binding.chkCrossCategory.setOnCheckedChangeListener { _, checked ->
            repository.crossCategory = checked
        }

        binding.chkAutoResume.isChecked = repository.autoResume
        binding.chkAutoResume.setOnCheckedChangeListener { _, checked ->
            repository.autoResume = checked
        }

        binding.chkAutoHide.isChecked = repository.autoHideOverlay
        binding.chkAutoHide.setOnCheckedChangeListener { _, checked ->
            repository.autoHideOverlay = checked
            if (checked) showOverlay()
        }

        // 定时关机：点击切换 关闭→30分钟→60分钟→90分钟→关闭
        updateSleepTimerUI()
        binding.tvSleepTimer.setOnClickListener {
            val current = repository.sleepTimerMinutes
            val next = when (current) {
                0 -> 30
                30 -> 60
                60 -> 90
                else -> 0
            }
            repository.sleepTimerMinutes = next
            updateSleepTimerUI()
            if (next > 0) {
                startSleepTimer(next)
                Toast.makeText(applicationContext, "${next}分钟后自动关机", Toast.LENGTH_SHORT).show()
            } else {
                cancelSleepTimer()
                Toast.makeText(applicationContext, "定时关机已取消", Toast.LENGTH_SHORT).show()
            }
        }

        // 开机自启动
        binding.chkAutoBoot.isChecked = repository.autoBoot
        binding.chkAutoBoot.setOnCheckedChangeListener { _, checked ->
            repository.autoBoot = checked
            if (checked) requestNotificationPermissionIfNeeded()
            Toast.makeText(applicationContext, if (checked) "开机自启动已开启" else "开机自启动已关闭", Toast.LENGTH_SHORT).show()
        }

        setupAspectRatioOptions()
        updateAspectRatioSelection()

        setupDecoderOptions()
        updateDecoderSelection()

        // 记住上次分组
        binding.chkRememberGroup.isChecked = rememberGroupPrefs().getBoolean("remember_group", false)
        binding.chkRememberGroup.setOnCheckedChangeListener { _, checked ->
            rememberGroupPrefs().edit().putBoolean("remember_group", checked).apply()
        }

        updateFavCount()

        binding.tvVersion.text = "v" + BuildConfig.VERSION_NAME
        binding.btnCheckUpdate.setOnClickListener { checkUpdate() }
        // 启动自动检查更新开关
        binding.switchAutoUpdate.isChecked = autoUpdateCheck
        binding.switchAutoUpdate.setOnCheckedChangeListener { _, isChecked ->
            autoUpdateCheck = isChecked
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                .putBoolean("auto_update_check", isChecked).apply()
        }

        refreshCrashLog()
        binding.btnExportCrashLog.setOnClickListener { launchCrashExport() }
        binding.btnExportAboutCrash.setOnClickListener { launchCrashExport() }
        binding.btnBackupConfig.setOnClickListener { launchBackup() }
        binding.btnRestoreConfig.setOnClickListener { confirmRestore() }
        binding.btnClearCrashLog.setOnClickListener {
            crashFile().delete()
            rememberGroupPrefs().edit().putBoolean("crash_prompted", false).apply()
            binding.tvCrashLog.text = "无"
            Toast.makeText(applicationContext, R.string.cleared_crash_log, Toast.LENGTH_SHORT).show()
        }

        // 退出
        binding.btnExitApp.setOnClickListener { confirmExit() }

        binding.tvAbout.text = getString(R.string.app_name) + " v" + BuildConfig.VERSION_NAME +
            "\n播放内核：Media3 ExoPlayer（开源）" +
            "\n代码仓库：https://github.com/cyj265/lanxing-tv" +
            "\n开源许可：Apache-2.0 / MIT / GPL-2.0" +
            "\n部分源码来自开源项目（详见仓库 README 来源致谢）"

        // 统一设置面板所有可聚焦元素的焦点样式（亮蓝背景+白字，和频道列表一致）
        applySettingsFocusStyles()
    }

    private fun setupSettingsTabs() {
        val navs = settingsNavs()
        navs.forEachIndexed { i, nav ->
            nav.setOnFocusChangeListener { _, focused ->
                if (focused) selectSettingsTab(i)
            }
        }
        // 退出导航：点击直接弹确认
        binding.navExit.setOnClickListener { confirmExit() }
        selectSettingsTab(0)
    }

        private fun refreshSettingsSourceInput() {
        try {
            refreshEpgUrlDisplay()
        } catch (ignored: Throwable) {
        }
    }

    /** 刷新直播源相关 UI（当前源标签 + 源列表 + 状态） */
    private fun refreshSourceUI() {
        try {
            updateCurrentSourceLabel()
            updateSourceOptions()
            updateSourceStatus()
            updateSourceBar()
        } catch (ignored: Throwable) {
        }
    }

    /** 更新当前源标签 */
    private fun updateCurrentSourceLabel() {
        try {
            val sources = repository.getSources()
            if (sources.isEmpty()) {
                binding.tvCurrentSource.text = "未配置直播源"
                return
            }
            val idx = repository.activeSourceIndex
            val url = sources.getOrNull(idx) ?: ""
            binding.tvCurrentSource.text = "源 " + (idx + 1) + "/" + sources.size + "  ·  " + sourceLabel(url)
        } catch (ignored: Throwable) {
        }
    }


    /** 删除指定源 */
    private fun deleteSource(index: Int) {
        val sources = repository.getSources().toMutableList()
        if (index < 0 || index >= sources.size) return
        val removed = sources.removeAt(index)
        if (sources.isEmpty()) {
            repository.saveSources(emptyList())
            repository.activeSourceIndex = 0
        } else {
            repository.saveSources(sources)
            if (repository.activeSourceIndex >= sources.size) {
                repository.activeSourceIndex = sources.size - 1
            }
        }
        currentChannel = null
        adapter.setSelected(null)
        refreshSourceUI()
        if (sources.isNotEmpty()) reloadPlaylist(true)
        Toast.makeText(applicationContext, "已删除直播源", Toast.LENGTH_SHORT).show()
    }


    private fun updateAutoSelectFastestUI() {
        try {
            if (repository.autoSelectFastest) {
                binding.tvAutoSelectFastest.text = "开"
                binding.tvAutoSelectFastest.setTextColor(0xFF4CAF50.toInt())
            } else {
                binding.tvAutoSelectFastest.text = "关"
                binding.tvAutoSelectFastest.setTextColor(0xFF9E9E9E.toInt())
            }
        } catch (ignored: Throwable) {}
    }

    private fun updateSourceStatus() {
        try {
            val sources = repository.getSources()
            val active = repository.getActiveSource()
            val sb = StringBuilder()
            sb.append("已配置 ").append(sources.size).append(" 个直播源")
            if (active != null) {
                sb.append("\n当前源：").append(sourceLabel(active))
                val updatedAt = repository.getSourceUpdatedAt(active)
                sb.append("\n").append(getString(R.string.source_updated)).append("：")
                sb.append(
                    if (updatedAt > 0)
                        SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(updatedAt))
                    else getString(R.string.source_never)
                )
            } else {
                sb.append("\n当前源：未配置")
            }
            val epgList = repository.getEpgUrls()
            sb.append("\n节目指南：").append(
                if (epgList.isEmpty()) "未设置" else "已配置 " + epgList.size + " 个地址"
            )
            val count = repository.epgProgramCount
            if (count > 0) sb.append("（已加载 ").append(count).append(" 条节目）")
            // v1.14.5：移除启动时的直播源状态 Toast，避免影响观感
            // 状态信息已在 tvStatus 中显示，用户可在设置中查看详细直播源信息
        } catch (ignored: Throwable) {
        }
    }

    private fun updateFavCount() {
        binding.tvFavCount.text = getString(R.string.fav_count, favorites.size)
    }

    private fun refreshCrashLog() {
        val f = crashFile()
        binding.tvCrashLog.text = if (f.exists()) {
            try {
                f.readText(Charsets.UTF_8)
            } catch (e: Exception) {
                "读取失败"
            }
        } else {
            "无"
        }
    }

    private fun launchCrashExport() {
        if (!crashFile().exists()) {
            Toast.makeText(applicationContext, R.string.export_empty, Toast.LENGTH_SHORT).show()
            return
        }
        val name = "app-log-" +
            SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault()).format(Date()) + ".txt"
        try {
            createLogDoc.launch(name)
        } catch (e: ActivityNotFoundException) {
            // TV 设备无文件管理器，降级到直接写入应用外部目录
            exportCrashLogToExternal(name)
        } catch (e: Exception) {
            Toast.makeText(applicationContext, "无法打开保存窗口：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** 降级方案：直接写入应用外部文件目录（无需权限，文件管理器可访问） */
    private fun exportCrashLogToExternal(name: String) {
        try {
            val dir = getExternalFilesDir(null) ?: filesDir
            val outFile = java.io.File(dir, name)
            crashFile().copyTo(outFile, overwrite = true)
            Toast.makeText(applicationContext, "已导出到：${outFile.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(applicationContext, "导出失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportCrashLogTo(uri: Uri) {
        try {
            val f = crashFile()
            if (!f.exists()) return
            val os = contentResolver.openOutputStream(uri)
            if (os == null) {
                Toast.makeText(applicationContext, "无法写入目标位置，请重试或选择其他位置", Toast.LENGTH_LONG).show()
                return
            }
            os.use { out ->
                out.write(f.readBytes())
            }
            Toast.makeText(applicationContext, R.string.exported, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(applicationContext, "导出失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- 配置备份 / 恢复（v1.16.0） ----------

    /** 构建备份 JSON：直播源 + 当前源 + EPG 地址 + 收藏 + 全部偏好 */
    private fun buildBackupJson(): JSONObject {
        val json = JSONObject()
        json.put("app", "lanxing-tv")
        json.put("version", 1)
        json.put("exportedAt", System.currentTimeMillis())
        val sourcesArr = JSONArray()
        repository.getSources().forEach { sourcesArr.put(it) }
        json.put("sources", sourcesArr)
        json.put("activeSourceIndex", repository.activeSourceIndex)
        val epgArr = JSONArray()
        repository.getEpgUrls().forEach { epgArr.put(it) }
        json.put("epgUrls", epgArr)
        val favArr = JSONArray()
        favorites.forEach { favArr.put(it) }
        json.put("favorites", favArr)
        val prefs = JSONObject()
        prefs.put("aspectRatio", repository.aspectRatio)
        prefs.put("autoResume", repository.autoResume)
        prefs.put("autoHideOverlay", repository.autoHideOverlay)
        prefs.put("sleepTimerMinutes", repository.sleepTimerMinutes)
        prefs.put("autoBoot", repository.autoBoot)
        prefs.put("switchTimeoutSec", repository.switchTimeoutSec)
        prefs.put("showClock", repository.showClock)
        prefs.put("showSpeed", repository.showSpeed)
        prefs.put("reverseZap", repository.reverseZap)
        prefs.put("crossCategory", repository.crossCategory)
        prefs.put("epgEnabled", repository.epgEnabled)
        prefs.put("epgRefreshHours", repository.epgRefreshHours)
        prefs.put("autoSelectFastest", repository.autoSelectFastest)
        // 解码方式是盒子上最常调的设置，也要跟着走
        prefs.put("decoderMode", playback.currentDecoderMode())
        prefs.put("autoUpdateCheck", autoUpdateCheck)
        prefs.put("rememberGroup", rememberGroupPrefs().getBoolean("remember_group", false))
        rememberGroupPrefs().getString("last_group", null)?.let { prefs.put("lastGroup", it) }
        json.put("prefs", prefs)
        json.put("lastChannelId", repository.lastChannelId ?: "")
        val collapsedArr = JSONArray()
        repository.getCollapsedGroups().forEach { collapsedArr.put(it) }
        json.put("collapsedGroups", collapsedArr)
        return json
    }

    private fun launchBackup() {
        val name = "lanxing-config-" +
            SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault()).format(Date()) + ".json"
        // 先保证写进应用目录再提示：电视盒子经常没有可用的系统文件选择器，
        // 之前直接拉起保存窗口，在盒子上表现为「点了没反应」，恢复时自然也找不到文件。
        val saved = saveBackupToAppDir(name) ?: return
        AlertDialog.Builder(this)
            .setTitle("备份完成")
            .setMessage(
                "已保存到：\n${saved.absolutePath}\n\n" +
                    "恢复时点「恢复配置」，直接在列表里选这份备份。\n" +
                    "注意：卸载应用会一并删除此文件。"
            )
            .setPositiveButton("完成", null)
            .setNeutralButton("另存到其他位置") { _, _ ->
                try {
                    createBackupDoc.launch(name)
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(applicationContext, "此设备没有可用的文件选择器，备份仍在应用目录", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(applicationContext, "无法打开保存窗口：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    /** 写入应用外部目录，失败时退回内部目录，返回写入的文件。 */
    private fun saveBackupToAppDir(name: String): File? {
        // 部分盒子的 /storage/emulated 写入会直接返回 ENOSPC，
        // 但 /data 正常，所以外部目录失败必须再试内部目录。
        val text = buildBackupJson().toString(2)
        val dirs = listOfNotNull(getExternalFilesDir(null), filesDir).distinct()
        var lastError: Exception? = null
        dirs.forEach { dir ->
            val outFile = File(dir, name)
            try {
                outFile.writeText(text, Charsets.UTF_8)
                return outFile
            } catch (e: Exception) {
                lastError = e
                outFile.delete()
            }
        }
        Toast.makeText(
            applicationContext,
            getString(R.string.backup_failed, lastError?.message ?: "未知错误"),
            Toast.LENGTH_LONG
        ).show()
        return null
    }

    private fun writeBackupTo(uri: Uri) {
        try {
            val os = contentResolver.openOutputStream(uri)
            if (os == null) {
                Toast.makeText(applicationContext, "无法写入目标位置，请重试或选择其他位置", Toast.LENGTH_LONG).show()
                return
            }
            os.use { out -> out.write(buildBackupJson().toString(2).toByteArray(Charsets.UTF_8)) }
            Toast.makeText(applicationContext, "已另存到所选位置", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(applicationContext, getString(R.string.backup_failed, e.message ?: "未知错误"), Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmRestore() {
        AlertDialog.Builder(this)
            .setTitle(R.string.restore_config)
            .setMessage(R.string.restore_confirm)
            .setPositiveButton("选择备份") { _, _ -> showRestoreFilePicker() }
            .setNegativeButton("取消", null)
            .show()
    }

    /** 应用目录里的备份文件（外部/内部都扫，按时间倒序，跳过写坏的 0 字节文件）。 */
    private fun listBackupFiles(): List<File> {
        val dirs = listOfNotNull(getExternalFilesDir(null), filesDir).distinct()
        return dirs.flatMap { dir ->
            dir.listFiles { f -> f.isFile && f.name.endsWith(".json", ignoreCase = true) }
                ?.toList().orEmpty()
        }.filter { it.length() > 0 }.sortedByDescending { it.lastModified() }
    }

    /** 先列应用目录里现成的备份（盒子上通常只有这条路可用），再提供系统选择器作为补充。 */
    private fun showRestoreFilePicker() {
        val files = listBackupFiles()
        if (files.isEmpty()) {
            openSystemRestorePicker("未找到备份文件，请先点「备份配置」生成备份")
            return
        }
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        val labels = files.map {
            "${it.name}（${fmt.format(Date(it.lastModified()))}，${(it.length() + 1023) / 1024} KB）"
        }
        // 平台 AlertDialog 白底，ListView 的选中行没有焦点样式、文字还会白底白字。
        // 这里改成自己排的焦点行：焦点实心蓝+白字，并默认停在最新一份备份上。
        val density = resources.displayMetrics.density
        val padH = (16 * density).toInt()
        val listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (6 * density).toInt(), 0, (6 * density).toInt())
        }
        val rowHeight = (52 * density).toInt()
        val rows = files.mapIndexed { i, f ->
            TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowHeight)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(padH, 0, padH, 0)
                text = labels[i]
                textSize = 15f
                isFocusable = true
                isClickable = true
                setBackgroundResource(R.drawable.bg_dialog_item)
                setTextColor(ContextCompat.getColorStateList(this@MainActivity, R.color.dialog_item_text))
                setOnClickListener { restoreFromFile(f) }
            }.also { listLayout.addView(it) }
        }
        val scroll = ScrollView(this).apply {
            // 最多显示 5 行，再多就滚动，避免备份很多时对话框超出屏幕
            val visibleRows = files.size.coerceAtMost(5)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ((visibleRows * 52 + 12) * density).toInt()
            )
            isFillViewport = false
            addView(listLayout)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("选择要恢复的备份")
            .setView(scroll)
            .setNeutralButton("从其他位置选择") { _, _ ->
                openSystemRestorePicker("此设备没有可用的文件选择器")
            }
            .setNegativeButton("取消", null)
            .create()
        dialog.setOnShowListener { rows.firstOrNull()?.requestFocus() }
        dialog.show()
    }

    private fun openSystemRestorePicker(emptyHint: String) {
        try {
            openRestoreDoc.launch(arrayOf("application/json", "application/octet-stream", "*/*"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(applicationContext, emptyHint, Toast.LENGTH_LONG).show()
        }
    }

    private fun restoreFromFile(f: File) {
        Thread {
            try {
                val text = f.readText(Charsets.UTF_8)
                if (text.isBlank()) {
                    runOnUiThread {
                        Toast.makeText(applicationContext, "这份备份是空文件，请重新点「备份配置」", Toast.LENGTH_LONG).show()
                    }
                    return@Thread
                }
                runOnUiThread { restoreFromJson(text) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(applicationContext,
                        getString(R.string.restore_failed, e.message ?: "未知错误"),
                        Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** 从 SAF Uri 读取备份并恢复（有系统文件选择器的设备走此路径） */
    private fun restoreFrom(uri: Uri) {
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null) {
                    runOnUiThread { Toast.makeText(applicationContext, R.string.restore_invalid, Toast.LENGTH_LONG).show() }
                    return@Thread
                }
                val text = String(bytes, Charsets.UTF_8)
                runOnUiThread { restoreFromJson(text) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(applicationContext,
                        getString(R.string.restore_failed, e.message ?: "未知错误"),
                        Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** 解析备份 JSON 并写回全部配置（UI 刷新在主线程执行） */
    private fun restoreFromJson(text: String) {
        Thread {
            try {
                val json = JSONObject(text)
                if (json.optString("app") != "lanxing-tv") {
                    runOnUiThread { Toast.makeText(applicationContext, R.string.restore_invalid, Toast.LENGTH_LONG).show() }
                    return@Thread
                }

                // 解析直播源与当前源
                val sources = mutableListOf<String>()
                val sourcesArr = json.optJSONArray("sources")
                if (sourcesArr != null) {
                    for (i in 0 until sourcesArr.length()) sources.add(sourcesArr.getString(i))
                }
                if (sources.isNotEmpty()) {
                    repository.saveSources(sources)
                    val idx = json.optInt("activeSourceIndex", 0).coerceIn(0, sources.size - 1)
                    repository.activeSourceIndex = idx
                }

                // EPG 地址
                val epgUrls = mutableListOf<String>()
                val epgArr = json.optJSONArray("epgUrls")
                if (epgArr != null) {
                    for (i in 0 until epgArr.length()) epgUrls.add(epgArr.getString(i))
                }
                repository.setEpgUrls(epgUrls)

                // 收藏
                val favs = mutableSetOf<String>()
                val favArr = json.optJSONArray("favorites")
                if (favArr != null) {
                    for (i in 0 until favArr.length()) favs.add(favArr.getString(i))
                }
                favorites = favs
                repository.setFavorites(favs)

                // 偏好
                var restoredDecoderMode: String? = null
                val prefs = json.optJSONObject("prefs")
                if (prefs != null) {
                    prefs.optString("aspectRatio").takeIf { it.isNotEmpty() }?.let { repository.aspectRatio = it }
                    prefs.optString("autoResume").takeIf { it.isNotEmpty() }?.let { repository.autoResume = it.toBoolean() }
                    prefs.optString("autoHideOverlay").takeIf { it.isNotEmpty() }?.let { repository.autoHideOverlay = it.toBoolean() }
                    prefs.optString("sleepTimerMinutes").takeIf { it.isNotEmpty() }?.let { repository.sleepTimerMinutes = it.toInt() }
                    prefs.optString("autoBoot").takeIf { it.isNotEmpty() }?.let { repository.autoBoot = it.toBoolean() }
                    prefs.optString("switchTimeoutSec").takeIf { it.isNotEmpty() }?.let { repository.switchTimeoutSec = it.toInt() }
                    prefs.optString("showClock").takeIf { it.isNotEmpty() }?.let { repository.showClock = it.toBoolean() }
                    prefs.optString("showSpeed").takeIf { it.isNotEmpty() }?.let { repository.showSpeed = it.toBoolean() }
                    prefs.optString("reverseZap").takeIf { it.isNotEmpty() }?.let { repository.reverseZap = it.toBoolean() }
                    prefs.optString("crossCategory").takeIf { it.isNotEmpty() }?.let { repository.crossCategory = it.toBoolean() }
                    prefs.optString("epgEnabled").takeIf { it.isNotEmpty() }?.let { repository.epgEnabled = it.toBoolean() }
                    prefs.optString("epgRefreshHours").takeIf { it.isNotEmpty() }?.let { repository.epgRefreshHours = it.toInt() }
                    prefs.optString("autoSelectFastest").takeIf { it.isNotEmpty() }?.let { repository.autoSelectFastest = it.toBoolean() }
                    // 解码方式：只记录，等回主线程再重建播放器
                    prefs.optString("decoderMode").takeIf { it in decoderModeCycle }?.let { restoredDecoderMode = it }
                    prefs.optString("autoUpdateCheck").takeIf { it.isNotEmpty() }?.let {
                        autoUpdateCheck = it.toBoolean()
                        getSharedPreferences("settings", MODE_PRIVATE).edit()
                            .putBoolean("auto_update_check", autoUpdateCheck).apply()
                    }
                    prefs.optString("rememberGroup").takeIf { it.isNotEmpty() }?.let {
                        rememberGroupPrefs().edit().putBoolean("remember_group", it.toBoolean()).apply()
                    }
                    prefs.optString("lastGroup").takeIf { it.isNotEmpty() }?.let {
                        rememberGroupPrefs().edit().putString("last_group", it).apply()
                    }
                }

                // 分组折叠状态 / 上次频道（旧备份没有这两项时保持现状）
                json.optJSONArray("collapsedGroups")?.let { arr ->
                    val collapsed = mutableSetOf<String>()
                    for (i in 0 until arr.length()) collapsed.add(arr.getString(i))
                    repository.saveCollapsedGroups(collapsed)
                }
                json.optString("lastChannelId").takeIf { it.isNotEmpty() }?.let {
                    repository.lastChannelId = it
                }

                runOnUiThread {
                    try {
                        // 刷新全部相关 UI
                        adapter.favorites = favorites
                        restoredDecoderMode?.let { playback.applyDecoderModeSilently(it) }
                        updateDecoderSelection()
                        binding.switchAutoUpdate.isChecked = autoUpdateCheck
                        binding.chkRememberGroup.isChecked =
                            rememberGroupPrefs().getBoolean("remember_group", false)
                        adapter.setCollapsedGroups(repository.getCollapsedGroups())
                        updateFavCount()
                        refreshSourceUI()
                        refreshSettingsSourceInput()
                        updateSourceOptions()
                        setupTimeoutOptions()
                        updateTimeoutSelection()
                        playback.setSourceTimeoutMs(repository.switchTimeoutSec * 1000L)
                        playback.setAspectRatio(repository.aspectRatio)
                        updateAspectRatioSelection()
                        updateAutoSelectFastestUI()
                        binding.chkShowClock.isChecked = repository.showClock
                        binding.chkShowSpeed.isChecked = repository.showSpeed
                        binding.chkReverseZap.isChecked = repository.reverseZap
                        binding.chkCrossCategory.isChecked = repository.crossCategory
                        binding.chkAutoResume.isChecked = repository.autoResume
                        binding.chkAutoHide.isChecked = repository.autoHideOverlay
                        binding.chkAutoBoot.isChecked = repository.autoBoot
                        updateSleepTimerUI()
                        refreshEpgUrlDisplay()
                        updateEpgEnabledUI()
                        updateEpgRefreshUI()
                        currentChannel = null
                        adapter.setSelected(null)
                        reloadPlaylist(true)
                        loadEpgIfConfigured()
                        Toast.makeText(applicationContext, R.string.restore_done, Toast.LENGTH_LONG).show()
                    } catch (e: Throwable) {
                        Toast.makeText(applicationContext, getString(R.string.restore_failed, e.message ?: "未知错误"), Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(applicationContext, getString(R.string.restore_failed, e.message ?: "未知错误"), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------- 超时换源 ----------

    private val timeoutCycle = listOf(5, 10, 15, 20, 25, 30, 60)

    private fun cycleTimeout() {
        val current = repository.switchTimeoutSec
        val idx = timeoutCycle.indexOf(current).let { if (it < 0) 0 else it }
        val next = timeoutCycle[(idx + 1) % timeoutCycle.size]
        repository.switchTimeoutSec = next
        playback.setSourceTimeoutMs(next * 1000L)
        updateTimeoutSelection()
        Toast.makeText(applicationContext, getString(R.string.switch_timeout) + "：" + next + " 秒", Toast.LENGTH_SHORT).show()
    }

    private fun updateTimeoutSelection() {
        val current = repository.switchTimeoutSec
        val timeoutViews = listOf(
            5 to binding.timeout5, 10 to binding.timeout10, 15 to binding.timeout15,
            20 to binding.timeout20, 25 to binding.timeout25, 30 to binding.timeout30,
            60 to binding.timeout60
        )
        for ((sec, view) in timeoutViews) {
            if (sec == current) {
                view.setBackgroundResource(R.drawable.bg_option_selected)
                view.setTextColor(0xFF7CB0FF.toInt())
                view.paint.isFakeBoldText = true
            } else {
                view.setBackgroundColor(0x00000000)
                view.setTextColor(0xFFCCCCCC.toInt())
                view.paint.isFakeBoldText = false
            }
        }
    }

    private fun setupTimeoutOptions() {
        val timeoutViews = listOf(
            5 to binding.timeout5, 10 to binding.timeout10, 15 to binding.timeout15,
            20 to binding.timeout20, 25 to binding.timeout25, 30 to binding.timeout30,
            60 to binding.timeout60
        )
        for ((sec, view) in timeoutViews) {
            applyOptionFocus(view) { updateTimeoutSelection() }
            view.setOnClickListener {
                repository.switchTimeoutSec = sec
                playback.setSourceTimeoutMs(sec * 1000L)
                updateTimeoutSelection()
                Toast.makeText(applicationContext, "换源超时：$sec 秒", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- 检查更新（自动下载安装） ----------

    /** 启动时静默检查更新：有更新弹窗确认，没更新不打扰，失败也不打扰 */
    /** 从 APK 文件名提取构建号，如 iptv-player-v244.apk -> 244 */
    private fun extractBuildNumber(apkFileName: String): Int {
        return try {
            val m = Regex("v(\\d+)\\.apk$").find(apkFileName)
            m?.groupValues?.get(1)?.toInt() ?: 0
        } catch (e: Exception) {
            0
        }
    }

    /**
     * 从 Release 说明里提取更新要点，只保留条目行，最多 6 条。
     * 说明为空或格式不符时返回空串，弹窗自动省略"本次更新"部分。
     */
    private fun formatReleaseNotes(body: String?): String {
        if (body.isNullOrBlank()) return ""
        val items = body.lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("- ") || it.startsWith("* ") }
            .map { it.removePrefix("* ").removePrefix("- ").trim() }
            .filter { it.isNotEmpty() }
            .toList()
        if (items.isEmpty()) return ""
        val shown = items.take(6)
        return buildString {
            for (item in shown) append("- ").append(item).append('\n')
            if (items.size > shown.size) append("…")
        }.trimEnd()
    }

    /** 更新弹窗文案：版本对比 + 本次更新要点。 */
    private fun buildUpdateMessage(tag: String, latestBuild: Int, notes: String): String =
        buildString {
            append("揽星TV v$tag (构建 #$latestBuild) 已发布\n")
            append("当前版本：v${BuildConfig.VERSION_NAME} (构建 #${BuildConfig.BUILD_NUMBER})")
            if (notes.isNotBlank()) append("\n\n本次更新：\n$notes")
            append("\n\n是否立即更新？")
        }

    /**
     * 拉取最新 Release JSON：先直连 GitHub API，失败后自动走 gh-proxy 加速线路。
     * 国内网络直连 api.github.com 经常超时/被重置，只靠直连会永远检测不到更新。
     */
    private fun fetchLatestReleaseJson(connectTimeoutMs: Int = 10000, readTimeoutMs: Int = 10000): JSONObject {
        val directUrl = "https://api.github.com/repos/cyj265/lanxing-tv/releases/latest"
        val urls = listOf(directUrl, "https://gh-proxy.com/$directUrl")
        var lastError: Exception? = null
        for (url in urls) {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = connectTimeoutMs
                conn.readTimeout = readTimeoutMs
                conn.setRequestProperty("User-Agent", "LanXingTV")
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                val code = conn.responseCode
                if (code !in 200..299) throw Exception("HTTP $code")
                return JSONObject(conn.inputStream.bufferedReader().readText())
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw lastError ?: Exception("网络错误")
    }

    private fun checkUpdateSilent() {
        // 本地节流：12 小时内只自动检查一次。GitHub 未认证 API 限流 60 次/小时/IP，
        // 公开用户在同一出口 IP 下频繁启动会触发 403，这里先自己降频。
        val now = System.currentTimeMillis()
        if (now - lastUpdateCheckAt < 12 * 3600_000L) return
        lastUpdateCheckAt = now
        try {
            getSharedPreferences("settings", MODE_PRIVATE)
                .edit().putLong("last_update_check", now).apply()
        } catch (ignored: Throwable) {
        }
        Thread {
            try {
                val json = fetchLatestReleaseJson()
                val tag = json.getString("tag_name").removePrefix("v").substringBefore("-b")
                val assets = json.getJSONArray("assets")
                var apkUrl: String? = null
                var apkName: String? = null
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.getString("name").endsWith(".apk")) {
                        apkUrl = a.getString("browser_download_url")
                        apkName = a.getString("name")
                        break
                    }
                }
                // 用构建号检测更新：即使版本号相同，构建号增加也提示
                val latestBuild = if (apkName != null) extractBuildNumber(apkName) else 0
                val currentBuild = BuildConfig.BUILD_NUMBER
                val newer = latestBuild > currentBuild
                if (newer && !apkUrl.isNullOrEmpty()) {
                    runOnUiThread {
                        try {
                            AlertDialog.Builder(this)
                                .setTitle("发现新版本")
                                .setMessage(buildUpdateMessage(tag, latestBuild, formatReleaseNotes(json.optString("body"))))
                                .setPositiveButton("立即更新") { _, _ ->
                                    downloadAndInstall(apkUrl)
                                }
                                .setNegativeButton("取消", null)
                                .show()
                        } catch (ignored: Throwable) {
                        }
                    }
                }
                // 没更新或没有APK：什么都不做（不打扰）
            } catch (e: Exception) {
                // 检查失败：不打扰用户，但留痕便于排查
                logUpdateIssue("autoCheck: fetch/parse", e)
            }
        }.start()
    }

    private fun checkUpdate() {
        binding.tvUpdateStatus.text = getString(R.string.checking_update)
        Thread {
            try {
                val json = fetchLatestReleaseJson(15000, 15000)
                val tag = json.getString("tag_name").removePrefix("v").substringBefore("-b")
                val assets = json.getJSONArray("assets")
                var apkUrl: String? = null
                var apkName: String? = null
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.getString("name").endsWith(".apk")) {
                        apkUrl = a.getString("browser_download_url")
                        apkName = a.getString("name")
                        break
                    }
                }
                // 用构建号检测更新
                val latestBuild = if (apkName != null) extractBuildNumber(apkName) else 0
                val currentBuild = BuildConfig.BUILD_NUMBER
                val newer = latestBuild > currentBuild
                runOnUiThread {
                    try {
                        if (!newer || apkUrl.isNullOrEmpty()) {
                            binding.tvUpdateStatus.text =
                                getString(R.string.update_latest) + "（v" + BuildConfig.VERSION_NAME + " #$currentBuild）"
                        } else {
                            binding.tvUpdateStatus.text =
                                getString(R.string.update_found) + " v" + tag + " #$latestBuild"
                            AlertDialog.Builder(this@MainActivity)
                                .setTitle("发现新版本")
                                .setMessage(buildUpdateMessage(tag, latestBuild, formatReleaseNotes(json.optString("body"))))
                                .setPositiveButton("立即更新") { _, _ ->
                                    downloadAndInstall(apkUrl)
                                }
                                .setNegativeButton("取消", null)
                                .show()
                        }
                    } catch (ignored: Throwable) {
                    }
                }
            } catch (e: Exception) {
                logUpdateIssue("manualCheck: fetch/parse", e)
                runOnUiThread {
                    try {
                        binding.tvUpdateStatus.text =
                            getString(R.string.update_failed, e.message ?: "网络错误")
                    } catch (ignored: Throwable) {
                    }
                }
            }
        }.start()
    }

    private fun compareVersions(a: String, b: String): Int {
        val pa = a.split(".").map { it.toIntOrNull() ?: 0 }
        val pb = b.split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(pa.size, pb.size)) {
            val x = pa.getOrElse(i) { 0 }
            val y = pb.getOrElse(i) { 0 }
            if (x != y) return x - y
        }
        return 0
    }

    private fun downloadAndInstall(originalUrl: String) {
        // 双线下载：先直连，失败自动换加速中转
        val proxyUrl = if (originalUrl.startsWith("https://github.com/")) {
            "https://gh-proxy.com/" + originalUrl
        } else {
            originalUrl
        }
        val urls = if (originalUrl == proxyUrl) {
            listOf(originalUrl)  // 非 GitHub 链接只有一条
        } else {
            listOf(originalUrl, proxyUrl)  // GitHub 链接：直连 + 加速
        }
        val urlNames = listOf("直连", "加速")

        Thread {
            var lastError: String? = null
            for ((idx, downloadUrl) in urls.withIndex()) {
                val urlName = if (urls.size > 1) urlNames.getOrElse(idx) { "线路${idx+1}" } else ""
                try {
                    runOnUiThread {
                        try {
                            binding.tvUpdateStatus.text = if (urlName.isNotEmpty()) "正在$urlName 下载..." else "正在下载..."
                        } catch (ignored: Throwable) {}
                    }
                    val dir = File(cacheDir, "apk")
                    dir.mkdirs()
                    val apk = File(dir, "update.apk")
                    val conn = URL(downloadUrl).openConnection() as HttpURLConnection
                    conn.connectTimeout = 15000
                    conn.readTimeout = 60000
                    conn.instanceFollowRedirects = true
                    conn.setRequestProperty("User-Agent", "LanXingTV")
                    val code = conn.responseCode
                    if (code !in 200..399) {
                        throw Exception("HTTP $code")
                    }
                    val total = conn.contentLengthLong
                    val input = conn.inputStream
                    val output = apk.outputStream()
                    val buf = ByteArray(64 * 1024)
                    var read: Int
                    var done = 0L
                    var lastPercent = -1
                    while (input.read(buf).also { read = it } > 0) {
                        output.write(buf, 0, read)
                        done += read
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPercent && pct % 5 == 0) {
                                lastPercent = pct
                                val p = pct
                                val name = urlName
                                runOnUiThread {
                                    try {
                                        binding.tvUpdateStatus.text = if (name.isNotEmpty()) "$name 下载中 $p%" else "下载中 $p%"
                                    } catch (ignored: Throwable) {}
                                }
                            }
                        }
                    }
                    output.flush()
                    output.close()
                    input.close()
                    // 下载成功，安装
                    runOnUiThread {
                        try {
                            binding.tvUpdateStatus.text = getString(R.string.update_done)
                            installApk(apk)
                        } catch (e: Throwable) {
                            logUpdateIssue("download: installApk", e)
                        }
                    }
                    return@Thread  // 下载成功，退出
                } catch (e: Exception) {
                    lastError = e.message ?: "下载失败"
                    logUpdateIssue("download: $urlName failed", e)
                    // 如果还有下一个链接，自动切换
                    if (idx < urls.size - 1) {
                        runOnUiThread {
                            try {
                                binding.tvUpdateStatus.text = "${urlName}失败（${lastError}），切换${urlNames[idx+1]}..."
                            } catch (ignored: Throwable) {}
                        }
                        Thread.sleep(500)
                    }
                }
            }
            // 所有链接都失败
            logUpdateIssue("download: all lines failed", Exception(lastError ?: "unknown"))
            runOnUiThread {
                try {
                    binding.tvUpdateStatus.text = getString(R.string.update_failed, lastError ?: "所有线路均下载失败")
                } catch (ignored: Throwable) {}
            }
        }.start()
    }

    /**
     * 拉起系统安装器。Android 8.0+ 目标来源未授权时系统会直接拒绝 ACTION_VIEW，
     * 因此先检测 canRequestPackageInstalls()，未授权则引导到系统授权页，返回后再装。
     */
    private fun installApk(apk: File) {
        try {
            if (!canInstallPackages()) {
                pendingInstallApk = apk
                showInstallPermissionDialog()
                return
            }
            launchInstaller(apk)
        } catch (e: Exception) {
            Toast.makeText(applicationContext, "无法打开安装器：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Android 8.0+ 需要"允许安装未知应用"授权；7.x 及以下没有这个限制 */
    private fun canInstallPackages(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                packageManager.canRequestPackageInstalls()
            } else {
                true
            }
        } catch (e: Exception) {
            true
        }
    }

    private fun showInstallPermissionDialog() {
        try {
            AlertDialog.Builder(this)
                .setTitle("需要授权安装更新")
                .setMessage(
                    "Android 要求先允许本应用安装更新包。\n\n" +
                        "点「去授权」后在系统页面打开「允许来自此来源的应用」，" +
                        "返回本应用即可继续安装。"
                )
                .setPositiveButton("去授权") { _, _ ->
                    try {
                        installPermissionLauncher.launch(
                            Intent(
                                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:$packageName")
                            )
                        )
                    } catch (e: Exception) {
                        Toast.makeText(applicationContext, "无法打开授权页面：${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
                .setNegativeButton("取消", null)
                .show()
        } catch (e: Exception) {
            Toast.makeText(applicationContext, "无法弹出授权提示：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchInstaller(apk: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(applicationContext, "无法打开安装器：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- 画面比例 ----------

    private val ratioCycle = listOf("fit", "16:9", "4:3", "zoom", "fill")

    // ---------- 解码方式 ----------

    private val decoderModeCycle = listOf("auto", "hardware", "software")

    private fun labelForMode(mode: String): String = when (mode) {
        "hardware" -> getString(R.string.decoder_hardware)
        "software" -> getString(R.string.decoder_software)
        else -> getString(R.string.decoder_auto)
    }

    private fun updateDecoderSelection() {
        val current = playback.currentDecoderMode()
        val decoderViews = listOf(
            "auto" to binding.decoderAuto,
            "hardware" to binding.decoderHard,
            "software" to binding.decoderSoft
        )
        for ((key, view) in decoderViews) {
            if (key == current) {
                view.setBackgroundResource(R.drawable.bg_option_selected)
                view.setTextColor(0xFF7CB0FF.toInt())
                view.paint.isFakeBoldText = true
            } else {
                view.setBackgroundColor(0x00000000)
                view.setTextColor(0xFFCCCCCC.toInt())
                view.paint.isFakeBoldText = false
            }
        }
    }

    private fun setupDecoderOptions() {
        val decoderViews = listOf(
            "auto" to binding.decoderAuto,
            "hardware" to binding.decoderHard,
            "software" to binding.decoderSoft
        )
        for ((key, view) in decoderViews) {
            applyOptionFocus(view) { updateDecoderSelection() }
            view.setOnClickListener {
                playback.applyDecoderMode(key)
                updateDecoderSelection()
                Toast.makeText(applicationContext, getString(R.string.decoder_mode) + "：" + labelForMode(key), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun cycleAspectRatio() {
        val current = repository.aspectRatio
        val idx = ratioCycle.indexOf(current)
        val next = ratioCycle[(idx + 1 + ratioCycle.size) % ratioCycle.size]
        repository.aspectRatio = next
        playback.setAspectRatio(next)
        updateAspectRatioSelection()
    }

    private fun updateAspectRatioSelection() {
        val current = repository.aspectRatio
        val ratioViews = listOf(
            "fit" to binding.ratiofit, "16:9" to binding.ratio169,
            "4:3" to binding.ratio43, "zoom" to binding.ratiozoom,
            "fill" to binding.ratiofill
        )
        for ((key, view) in ratioViews) {
            if (key == current) {
                view.setBackgroundResource(R.drawable.bg_option_selected)
                view.setTextColor(0xFF7CB0FF.toInt())
                view.paint.isFakeBoldText = true
            } else {
                view.setBackgroundColor(0x00000000)
                view.setTextColor(0xFFCCCCCC.toInt())
                view.paint.isFakeBoldText = false
            }
        }
    }

    private fun setupAspectRatioOptions() {
        val ratioViews = listOf(
            "fit" to binding.ratiofit, "16:9" to binding.ratio169,
            "4:3" to binding.ratio43, "zoom" to binding.ratiozoom,
            "fill" to binding.ratiofill
        )
        for ((key, view) in ratioViews) {
            applyOptionFocus(view) { updateAspectRatioSelection() }
            view.setOnClickListener {
                repository.aspectRatio = key
                playback.setAspectRatio(key)
                updateAspectRatioSelection()
                val label = when (key) {
                    "16:9" -> "16:9"
                    "4:3" -> "4:3"
                    "zoom" -> "缩放"
                    "fill" -> "填充"
                    else -> "适应"
                }
                Toast.makeText(applicationContext, "画面比例：$label", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- 播放列表加载 ----------


    private fun reloadPlaylist(forceRefresh: Boolean = false) {
        val url = repository.getActiveSource()
        if (url.isNullOrEmpty()) {
            val cached = repository.loadLocalChannels()
            if (!cached.isNullOrEmpty()) onChannelsLoaded(cached)
            return
        }
        // ★ v1.13.1：直播源缓存 24 小时内直接使用（频道列表相对稳定，无需每次启动重新下载）。
        // 用户手动操作（切换源/保存/扫码/刷新）时 forceRefresh=true 强制下载最新列表。
        if (!forceRefresh) {
            val updatedAt = repository.getSourceUpdatedAt(url)
            val cached = repository.loadCachedChannels(url)
            if (updatedAt > 0 &&
                System.currentTimeMillis() - updatedAt < 24 * 3600_000L &&
                !cached.isNullOrEmpty()
            ) {
                onChannelsLoaded(cached)
                return
            }
        }
        Thread {
            try {
                val content = HttpLoader.fetch(url)
                val channels = PlaylistParser.parseAuto(content)
                // v1.16.0：M3U 头部 url-tvg 自动预填 EPG（仅当尚未配置节目单时）
                if (repository.getEpgUrls().isEmpty()) {
                    val epgFromM3u = PlaylistParser.extractEpgUrls(content)
                    if (epgFromM3u.isNotEmpty()) {
                        repository.setEpgUrls(epgFromM3u)
                        runOnUiThread {
                            try {
                                refreshEpgUrlDisplay()
                                loadEpgIfConfigured()
                                Toast.makeText(applicationContext, "已从播放列表自动识别节目单地址", Toast.LENGTH_SHORT).show()
                            } catch (ignored: Throwable) {}
                        }
                    }
                }
                if (channels.isNotEmpty()) {
                    repository.saveChannels(channels, url)
                }
                runOnUiThread {
                    try {
                        onChannelsLoaded(channels)
                    } catch (e: Throwable) {
                        binding.tvStatus.text =
                            getString(R.string.load_failed) + "：" + (e.message ?: "列表渲染失败")
                    }
                }
            } catch (e: Throwable) {
                val cached = repository.loadCachedChannels(url)
                val detail = e.message ?: e.javaClass.simpleName
                runOnUiThread {
                    try {
                        if (!cached.isNullOrEmpty()) {
                            onChannelsLoaded(cached)
                            binding.tvStatus.text = getString(R.string.load_failed) + "（已用缓存）"
                        } else {
                            binding.tvStatus.text = getString(R.string.load_failed) + "：" + detail
                            Toast.makeText(applicationContext, R.string.load_failed, Toast.LENGTH_SHORT).show()
                        }
                    } catch (e2: Throwable) {
                        binding.tvStatus.text =
                            getString(R.string.load_failed) + "：" + (e2.message ?: "未知错误")
                    }
                }
            }
        }.start()
    }

    private fun onChannelsLoaded(channels: List<Channel>) {
        allChannels = channels
        binding.tvStatus.text = getString(R.string.channel_list) + " · " + channels.size + " 个频道"
        // 更新左侧分组列表
        val groupSet = LinkedHashSet<String?>()
        groupSet.add(null)  // 全部
        channels.forEach { groupSet.add(it.group) }
        groupAdapter.submitGroups(groupSet.toList())
        groupAdapter.setSelected(currentGroup)
        applyFilter()
        if (channels.isEmpty()) {
            binding.tvChannelName.text = getString(R.string.no_channels_guide)
            binding.tvChannelName.maxLines = 3
        } else {
            binding.tvChannelName.maxLines = 1
        }
        updateSourceBar()
        updateSourceStatus()
        loadEpgIfConfigured()
        // 启动播放统一由 waitForSurfaceAndResume() 处理（等 surfaceCreated 后再播）。
        // 仅当 surface 已就绪（说明 waitForSurfaceAndResume 已执行过但当时无频道可播）
        // 且当前还没播放时，才在这里补调一次，避免重复初始化播放器。
        if (currentChannel == null && channels.isNotEmpty() && repository.autoResume && surfaceReady) {
            logStartup("onChannelsLoaded: surface already ready but no channel playing, resumeLastChannel")
            resumeLastChannel()
        }
    }

    // ---------- 本地文件导入 ----------

    private fun importLocalFile(uri: Uri) {
        Thread {
            try {
                val content = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (content == null) return@Thread
                var text = String(content, Charsets.UTF_8)
                if (text.contains('\uFFFD')) {
                    text = String(content, java.nio.charset.Charset.forName("GBK"))
                }
                val channels = PlaylistParser.parseAuto(text)
                // v1.16.0：本地 M3U 头部 url-tvg 自动预填 EPG
                if (repository.getEpgUrls().isEmpty()) {
                    val epgFromM3u = PlaylistParser.extractEpgUrls(text)
                    if (epgFromM3u.isNotEmpty()) {
                        repository.setEpgUrls(epgFromM3u)
                        runOnUiThread {
                            try {
                                refreshEpgUrlDisplay()
                                loadEpgIfConfigured()
                            } catch (ignored: Throwable) {}
                        }
                    }
                }
                if (channels.isEmpty()) {
                    runOnUiThread { Toast.makeText(applicationContext, R.string.no_channels, Toast.LENGTH_SHORT).show() }
                    return@Thread
                }
                repository.saveLocalChannels(channels)
                runOnUiThread {
                    try {
                        onChannelsLoaded(channels)
                        hideSettingsPanel()
                        Toast.makeText(applicationContext, R.string.importing, Toast.LENGTH_SHORT).show()
                    } catch (e: Throwable) {
                        Toast.makeText(applicationContext, R.string.load_failed, Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(applicationContext, R.string.load_failed, Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }


    // ---------- 频道筛选 ----------

    private val previewHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var previewRunnable: Runnable? = null

    /** 已废弃：频道焦点移动不再自动换台（OK 键才播放），避免频繁播放导致卡顿 */
    private fun previewChannel(ch: com.cyj265.iptvplayer.data.Channel) {
        // no-op: 焦点移动只更新节目信息，OK 才播放
    }

    private fun applyFilter() {
        try {
            val query = binding.searchInput.text.toString().trim().lowercase(Locale.getDefault())
            val filtered = allChannels.filter { ch ->
                val matchQuery = query.isEmpty() || ch.name.lowercase(Locale.getDefault()).contains(query)
                val matchFav = !showFavoritesOnly || favorites.contains(ch.url)
                val matchGroup = currentGroup == null || ch.group == currentGroup
                matchQuery && matchFav && matchGroup
            }
            adapter.submitChannels(filtered)
            adapter.setSelected(currentChannel?.id)
        } catch (ignored: Throwable) {
        }
    }

    // ---------- 播放 ----------

    private fun onChannelClick(channel: Channel) {
        currentChannel = channel
        repository.lastChannelId = channel.id
        adapter.setSelected(channel.id)
        updateProgramInfo()
        playback.play(channel.sources.ifEmpty { listOf(channel.url) }, channel.name)
        updateNowPlaying()
        hideChannelPanel()
    }

    private var surfaceReady = false
    private var surfaceResumePending = false
    private val surfaceResumeHandler = android.os.Handler(android.os.Looper.getMainLooper())

    /** 等待 SurfaceView 的 Surface 创建完成后再恢复播放，避免渲染到未就绪 Surface 导致黑屏闪退 */
    /** 遍历 PlayerView 子视图查找 SurfaceView（兼容各版本 Media3 API） */
    private fun findSurfaceView(view: android.view.View): android.view.SurfaceView? {
        if (view is android.view.SurfaceView) return view
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                val child = view.getChildAt(i)
                val result = findSurfaceView(child)
                if (result != null) return result
            }
        }
        return null
    }

    private fun waitForSurfaceAndResume() {
        try {
            val surfaceView = findSurfaceView(binding.playerView)
            if (surfaceView != null) {
                val holder = surfaceView.holder
                if (holder.surface != null && holder.surface.isValid) {
                    // Surface 已就绪，直接播放
                    surfaceReady = true
                    logStartup("Surface already ready, resume immediately")
                    resumeLastChannel()
                    return
                }
                // 等待 surfaceCreated 回调
                surfaceResumePending = true
                logStartup("Surface not ready, waiting for surfaceCreated...")
                holder.addCallback(object : android.view.SurfaceHolder.Callback {
                    override fun surfaceCreated(h: android.view.SurfaceHolder) {
                        surfaceReady = true
                        logStartup("surfaceCreated callback received")
                        if (surfaceResumePending) {
                            surfaceResumePending = false
                            resumeLastChannel()
                        }
                        h.removeCallback(this)
                    }
                    override fun surfaceChanged(h: android.view.SurfaceHolder, format: Int, width: Int, height: Int) {}
                    override fun surfaceDestroyed(h: android.view.SurfaceHolder) {
                        surfaceReady = false
                        logStartup("surfaceDestroyed callback received")
                    }
                })
                // 超时保护：5秒内 Surface 未就绪则强制播放
                surfaceResumeHandler.postDelayed({
                    if (surfaceResumePending) {
                        surfaceResumePending = false
                        logStartup("Surface wait timeout (5s), force resume")
                        resumeLastChannel()
                    }
                }, 5000)
            } else {
                logStartup("SurfaceView not found, fallback to delayed resume")
                surfaceResumeHandler.postDelayed({ resumeLastChannel() }, 500)
            }
        } catch (e: Exception) {
            logStartup("waitForSurfaceAndResume exception: ${e.message}")
            window.decorView.postDelayed({ resumeLastChannel() }, 500)
        }
    }

    // ---------- 定时关机 ----------
    private fun updateSleepTimerUI() {
        val minutes = repository.sleepTimerMinutes
        val text = if (minutes == 0) "定时关机：关闭" else "定时关机：${minutes}分钟"
        binding.tvSleepTimer.text = text
    }

    private fun startSleepTimer(minutes: Int) {
        cancelSleepTimer()
        sleepTimerEndTime = System.currentTimeMillis() + minutes * 60 * 1000L
        sleepTimerHandler.postDelayed(sleepTimerRunnable, minutes * 60 * 1000L)
    }

    private fun cancelSleepTimer() {
        sleepTimerHandler.removeCallbacks(sleepTimerRunnable)
        sleepTimerEndTime = 0
    }

    /** 启动日志：写入 app.log 便于定位启动/播放问题 */
    private fun logStartup(msg: String) {
        try {
            val file = crashFile()
            // 日志大小限制：超过 500KB 自动清空，避免长期使用占用过多存储空间
            if (file.exists() && file.length() > 500 * 1024) {
                file.delete()
            }
            val timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())
            // 追加写入：启动时该方法会连续调用多次，原来的 readText + writeText
            // 每次都全量重写整个日志（上限 500KB），在启动主线程上是无谓的 IO 负担。
            file.appendText("\n[$timestamp][Startup] $msg", Charsets.UTF_8)
        } catch (ignored: Exception) {}
    }

    /**
     * 更新链路的失败留痕：写到与启动日志同一个文件，用户报「更新没反应」时可查到具体环节。
     * 内部全程兜底，绝不因写日志失败影响更新流程。
     */
    private fun logUpdateIssue(where: String, e: Throwable?) {
        try {
            Log.w("LanXingTV-Update", where, e)
        } catch (ignored: Throwable) {}
        try {
            val file = crashFile()
            if (file.exists() && file.length() > 500 * 1024) file.delete()
            val timestamp = java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault()
            ).format(java.util.Date())
            val detail = (e?.javaClass?.simpleName ?: "-") + ": " + (e?.message ?: "-")
            file.appendText(
                "${System.lineSeparator()}[$timestamp][Update] $where: $detail",
                Charsets.UTF_8
            )
        } catch (ignored: Throwable) {}
    }

    private fun resumeLastChannel() {
        val lastId = repository.lastChannelId
        if (lastId == null) {
            logStartup("resumeLastChannel: lastChannelId is null, skip")
            return
        }
        val ch = allChannels.firstOrNull { it.id == lastId }
        if (ch == null) {
            logStartup("resumeLastChannel: channel not found for id=$lastId, channels=${allChannels.size}, skip")
            return
        }
        logStartup("resumeLastChannel: playing channel=${ch.name} sources=${ch.sources.size}")
        currentChannel = ch
        adapter.setSelected(ch.id)
        playback.play(ch.sources.ifEmpty { listOf(ch.url) }, ch.name)
        updateNowPlaying()
        logStartup("resumeLastChannel: playback.play() called")
    }

    private fun playDirect(url: String, name: String) {
        val channel = Channel(
            id = "direct-${url.hashCode()}",
            name = name,
            url = url,
            group = "直接播放",
            logo = "",
            tvgId = name
        )
        currentChannel = channel
        repository.lastChannelId = channel.id
        adapter.setSelected(null)
        playback.play(listOf(url), name)
        updateNowPlaying()
    }

    /**
     * 换台防抖：遥控器按住上下键会连发 KEYCODE_DPAD_UP/DOWN，
     * 若每次都立即起播，播放器会在几十毫秒内反复重建，N1 上极易触发解码器初始化失败/黑屏。
     * 这里把连发合并：期间只更新标题提示，停手 ~260ms 后只播放最终停留的频道。
     */
    private companion object {
        const val CHANNEL_SWITCH_DEBOUNCE_MS = 260L

        /**
         * 频道名归一化正则：全局只编译一次。
         * 之前 normalizeEpgName 每次调用都 Regex(...) → Pattern.compile()，
         * 而 EPG 索引会对数千条节目逐条归一化，在 onCreate 主线程触发
         * 数千次正则编译，导致启动 ANR（Bugly #2008 / ANR_EXCEPTION）。
         */
        private val EPG_NAME_CLEAN = Regex("[^a-z0-9\u4e00-\u9fa5]")
        private val EPG_QUALITY_SUFFIXES = listOf(
            "极清", "超清", "高清", "标清", "流畅", "原画", "蓝光",
            "4k", "8k", "uhd", "fhd", "hd", "sd", "2160p", "1080p", "720p"
        )
    }
    private val switchHandler = Handler(Looper.getMainLooper())
    private var pendingSwitchDelta = 0
    private var lastSwitchAt = 0L
    private val pendingSwitchRunnable = Runnable {
        val delta = pendingSwitchDelta
        pendingSwitchDelta = 0
        if (delta != 0) performSwitchChannel(delta)
    }

    private fun switchChannel(delta: Int) {
        if (allChannels.isEmpty()) return
        val now = System.currentTimeMillis()
        val isBurst = now - lastSwitchAt < CHANNEL_SWITCH_DEBOUNCE_MS
        if (!isBurst && pendingSwitchDelta == 0) {
            performSwitchChannel(delta)
            return
        }
        // 连发：累积位移，延迟到停手后再真正起播
        pendingSwitchDelta += delta
        switchHandler.removeCallbacks(pendingSwitchRunnable)
        switchHandler.postDelayed(pendingSwitchRunnable, CHANNEL_SWITCH_DEBOUNCE_MS)
        // 期间只提示将切到的频道，不重建播放器
        resolveTargetChannel(pendingSwitchDelta)?.let { showPendingChannelHint(it) }
    }

    /** 连按换台期间的轻量提示：只改标题文字，不起播。 */
    private fun showPendingChannelHint(ch: Channel) {
        try {
            binding.tvChannelName.maxLines = 1
            binding.tvChannelName.text = "→ ${ch.name}"
        } catch (ignored: Throwable) {
        }
    }

    /** 按位移计算目标频道（不播放）。 */
    private fun resolveTargetChannel(delta: Int): Channel? {
        if (allChannels.isEmpty()) return null
        val current = currentChannel
        val realDelta = if (repository.reverseZap) -delta else delta
        if (showFavoritesOnly) {
            val favChannels = allChannels.filter { favorites.contains(it.url) }
            if (favChannels.isEmpty()) return null
            val favIdx = favChannels.indexOfFirst { it.id == current?.id }
            val next = if (favIdx < 0) 0 else (favIdx + realDelta + favChannels.size) % favChannels.size
            return favChannels[next]
        }
        // 跨选分类：关闭时只在当前分组内循环
        if (!repository.crossCategory && current != null) {
            val sameGroup = allChannels.filter { it.group == current.group }
            if (sameGroup.size > 1) {
                val gIdx = sameGroup.indexOfFirst { it.id == current.id }
                val next = if (gIdx < 0) 0 else (gIdx + realDelta + sameGroup.size) % sameGroup.size
                return sameGroup[next]
            }
        }
        val idx = allChannels.indexOfFirst { it.id == current?.id }
        val next = if (idx < 0) 0 else (idx + realDelta + allChannels.size) % allChannels.size
        return allChannels[next]
    }

    private fun performSwitchChannel(delta: Int) {
        val target = resolveTargetChannel(delta) ?: return
        lastSwitchAt = System.currentTimeMillis()
        onChannelClick(target)
    }

    private fun toggleFavoriteCurrent() {
        val ch = currentChannel
        if (ch == null) {
            Toast.makeText(applicationContext, "当前没有正在播放的频道", Toast.LENGTH_SHORT).show()
            return
        }
        toggleFavorite(ch)
    }

    /** 收藏/取消收藏：优先作用于频道列表中当前获得焦点的频道，其次正在播放的频道。 */
    private fun toggleFavoriteFocused() {
        val ch = lastFocusedChannel ?: currentChannel
        if (ch == null) {
            Toast.makeText(applicationContext, "请先把焦点移到要收藏的频道", Toast.LENGTH_SHORT).show()
            return
        }
        toggleFavorite(ch)
    }

    private fun toggleFavorite(ch: Channel) {
        val added = if (favorites.contains(ch.url)) {
            favorites.remove(ch.url)
            false
        } else {
            favorites.add(ch.url)
            true
        }
        repository.setFavorites(favorites)
        adapter.favorites = favorites
        // 仅收藏筛选模式下需要重刷列表；否则只刷新星标并原地恢复焦点
        if (showFavoritesOnly) {
            applyFilter()
        } else {
            refreshFavoriteMarks()
        }
        updateFavoriteIcon()
        updateFavCount()
        Toast.makeText(
            applicationContext,
            if (added) getString(R.string.favorite_added, ch.name) else getString(R.string.favorite_removed, ch.name),
            Toast.LENGTH_SHORT
        ).show()
    }

    /** 只刷新频道行的收藏星标：记住焦点行位置，刷新后原地恢复，避免跳位/丢焦点。 */
    private fun refreshFavoriteMarks() {
        val focusedChild = binding.channelList.focusedChild
        val focusedPos = if (focusedChild != null) {
            binding.channelList.getChildAdapterPosition(focusedChild)
        } else {
            -1
        }
        adapter.notifyDataSetChanged()
        if (focusedPos >= 0) {
            binding.channelList.post {
                binding.channelList.findViewHolderForAdapterPosition(focusedPos)?.itemView?.requestFocus()
            }
        }
    }

    private fun updateFavoriteIcon() {
        val focused = lastFocusedChannel ?: currentChannel
        val focusedFav = focused?.let { favorites.contains(it.url) } == true
        // 已收藏：高亮金色 + 不透明；未收藏：灰色半透明
        binding.btnFavoriteFocused.alpha = if (focusedFav) 1f else 0.45f
        binding.btnFavoriteFocused.setColorFilter(
            if (focusedFav) resources.getColor(R.color.accent, theme)
            else resources.getColor(R.color.text_secondary, theme)
        )
        binding.btnFavorites.setTextColor(
            if (showFavoritesOnly) resources.getColor(R.color.accent, theme)
            else resources.getColor(R.color.text_secondary, theme)
        )
    }

    // ---------- EPG（支持多个地址，全部加载合并） ----------

    /**
     * 定时刷新节目单（每 5 分钟检查一次）：
     * 超过设置的刷新间隔（默认 2 小时）才后台重新拉取，静默进行不弹 Toast。
     */
    private fun maybeRefreshEpg() {
        try {
            if (!repository.epgEnabled) return
            if (epgLoadState == EpgLoadState.LOADING) return
            if (repository.getEpgUrls().isEmpty()) return
            val now = System.currentTimeMillis()
            val updatedAt = repository.epgUpdatedAt
            val interval = repository.epgRefreshHours.coerceAtLeast(1) * 3600_000L
            // 成功加载过且未到刷新间隔 → 不动
            if (updatedAt > 0 && now - updatedAt < interval) return
            // 从未成功加载过（updatedAt=0）时交给手动刷新，避免持续失败时反复轰炸网络
            if (updatedAt <= 0) return
            // 距上次尝试至少 30 分钟，防止网络不通时反复重试
            if (now - lastEpgAttemptAt < 30 * 60_000L) return
            loadEpgIfConfigured(silent = true)
        } catch (ignored: Throwable) {
        }
    }

    /** silent=true 用于定时刷新，不再弹"加载成功/失败"的 Toast 打扰用户 */
    private fun loadEpgIfConfigured(silent: Boolean = false) {
        // v1.14.0：节目单开关（设置里可关闭）
        if (!repository.epgEnabled) {
            epgLoadState = EpgLoadState.NOT_CONFIGURED
            epgPrograms = emptyMap()
            updateNowPlaying()
            return
        }
        val epgUrls = repository.getEpgUrls()
        if (epgUrls.isEmpty()) {
            epgLoadState = EpgLoadState.NOT_CONFIGURED
            updateNowPlaying()
            return
        }
        // 节流：距上次尝试不足 10 秒不重复加载
        val nowMs = System.currentTimeMillis()
        if (nowMs - lastEpgAttemptAt < 10000 && epgLoadState == EpgLoadState.LOADING) return
        if (epgLoadInFlight) return  // 启动加载 / 定时刷新 / 手动刷新并发时只保留第一个
        lastEpgAttemptAt = nowMs
        // ★ EPG 本地缓存按时间线直接显示，有效期内无需重新下载。
        // 缓存 JSON 约 1MB / 数千条节目，读取与建索引必须放在子线程：
        // 之前在主线程执行，onCreate 被阻塞触发 ANR（Bugly #2008）。
        val cachedAge = nowMs - repository.epgUpdatedAt
        val cacheThresholdMs = repository.epgRefreshHours * 3600_000L
        val cacheUsable = cachedAge in 0 until cacheThresholdMs
        epgLoadInFlight = true
        epgLoadState = EpgLoadState.LOADING
        updateProgramInfo()
        Thread {
            try {
                // ① 缓存命中：后台读 1MB JSON + 建索引，完成后回主线程刷新 UI
                if (cacheUsable) {
                    val epgCache = repository.loadEpgCache()
                    if (epgCache != null) {
                        // 子线程取 allChannels 快照，避免与主线程 onChannelsLoaded 的赋值产生可见性问题
                        val indexed = indexEpgWithChannels(epgCache, allChannels)
                        runOnUiThread {
                            if (isFinishing || isDestroyed) return@runOnUiThread
                            try {
                                epgPrograms = indexed
                                epgLoadState = EpgLoadState.READY
                                updateNowPlaying()
                                adapter.epgNow = buildEpgNowMap()
                                adapter.epgNext = buildEpgNextMap()
                                updateProgramInfo()
                            } catch (ignored: Throwable) {
                            }
                        }
                        return@Thread
                    }
                }
                // ② 缓存不存在 / 已过期 / 损坏 → 走网络加载
                var totalPrograms = 0
                val mergedPrograms = ArrayList<EpgProgram>()
                val mergedNames = HashMap<String, String>()
                var loadError: String? = null
                try {
                    for (epgUrl in epgUrls) {
                        try {
                            val content = HttpLoader.fetch(epgUrl)
                            val data = EpgParser.parse(content)
                            mergedPrograms.addAll(data.programs)
                            mergedNames.putAll(data.channelNames)
                            totalPrograms += data.programs.size
                        } catch (e: Exception) {
                            if (loadError == null) loadError = e.message ?: e.javaClass.simpleName
                        }
                    }
                } catch (e: Exception) {
                    if (loadError == null) loadError = e.message ?: e.javaClass.simpleName
                }
                val finalState: EpgLoadState
                if (mergedPrograms.isEmpty()) {
                    finalState = EpgLoadState.FAILED
                } else {
                    // 修复：子线程中先取 allChannels 快照，避免与主线程 onChannelsLoaded
                    // 的赋值产生可见性问题（List 虽不可变，但显式快照更安全）
                    val channelsSnapshot = allChannels
                    epgPrograms = indexEpgWithChannels(EpgParser.EpgData(mergedNames, mergedPrograms), channelsSnapshot)
                    repository.epgProgramCount = totalPrograms
                    repository.epgUpdatedAt = System.currentTimeMillis()
                    repository.saveEpgCache(mergedNames, mergedPrograms)
                    epgLoadedCount = totalPrograms
                    finalState = EpgLoadState.READY
                }
                val err = loadError
                runOnUiThread {
                    try {
                        epgLoadState = finalState
                        updateNowPlaying()
                        adapter.epgNow = buildEpgNowMap()
                        adapter.epgNext = buildEpgNextMap()
                        updateProgramInfo()
                        updateSourceStatus()
                        if (finalState == EpgLoadState.FAILED) {
                            if (!silent) {
                                Toast.makeText(
                                    applicationContext,
                                    "节目指南加载失败" + (if (err != null) "：" + err else ""),
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } else if (finalState == EpgLoadState.READY && totalPrograms > 0 && !silent) {
                            Toast.makeText(
                                applicationContext,
                                "节目指南加载成功（" + totalPrograms + " 条节目）",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (ignored: Throwable) {
                    }
                }
            } finally {
                epgLoadInFlight = false
            }
        }.start()
    }

    /** 频道名归一化：小写、去符号空格、去画质后缀（极清/高清/4K…），用于 EPG 模糊匹配 */
    private fun normalizeEpgName(name: String): String {
        var s = name.trim().lowercase(Locale.getDefault())
        s = EPG_NAME_CLEAN.replace(s, "")
        for (suffix in EPG_QUALITY_SUFFIXES) {
            s = s.removeSuffix(suffix)
        }
        return s
    }

    private fun indexEpg(data: EpgParser.EpgData): Map<String, List<EpgProgram>> {
        val map = HashMap<String, List<EpgProgram>>()
        val byName = HashMap<String, MutableList<EpgProgram>>()
        val byNorm = HashMap<String, MutableList<EpgProgram>>()
        for (p in data.programs) {
            byName.getOrPut(p.channelId) { ArrayList() }.add(p)
        }
        // 只对「不同的 channelId」归一化一次：数千条节目通常只对应约百个频道，
        // 避免逐条节目重复做字符串归一化（配合预编译正则，索引耗时降一个数量级）。
        for ((channelId, list) in byName) {
            byNorm.getOrPut(normalizeEpgName(channelId)) { ArrayList() }.addAll(list)
        }
        for (ch in allChannels) {
            // 1) 精确匹配 tvgId / 频道名
            var list = byName[ch.tvgId] ?: byName[ch.name]
            // 2) 归一化匹配（覆盖"频道名带画质后缀"的常见情况）
            if (list == null) {
                list = byNorm[normalizeEpgName(ch.name)]
            }
            if (list != null) map[ch.id] = list.sortedBy { it.start }
        }
        return map
    }

    /** 带频道快照的 EPG 索引（子线程安全版本） */
    private fun indexEpgWithChannels(data: EpgParser.EpgData, channels: List<Channel>): Map<String, List<EpgProgram>> {
        val map = HashMap<String, List<EpgProgram>>()
        val byName = HashMap<String, MutableList<EpgProgram>>()
        val byNorm = HashMap<String, MutableList<EpgProgram>>()
        for (p in data.programs) {
            byName.getOrPut(p.channelId) { ArrayList() }.add(p)
        }
        // 只对「不同的 channelId」归一化一次：数千条节目通常只对应约百个频道，
        // 避免逐条节目重复做字符串归一化（配合预编译正则，索引耗时降一个数量级）。
        for ((channelId, list) in byName) {
            byNorm.getOrPut(normalizeEpgName(channelId)) { ArrayList() }.addAll(list)
        }
        for (ch in channels) {
            var list = byName[ch.tvgId] ?: byName[ch.name]
            if (list == null) {
                list = byNorm[normalizeEpgName(ch.name)]
            }
            if (list != null) map[ch.id] = list.sortedBy { it.start }
        }
        return map
    }

    /** 构建"正在播放"节目文本映射（频道列表副行用）。 */
    private fun buildEpgNowMap(): Map<String, String> {
        val now = System.currentTimeMillis()
        val map = HashMap<String, String>()
        for (ch in allChannels) {
            val programs = epgPrograms[ch.id] ?: continue
            val cur = programs.firstOrNull { now in it.start until it.end }
            if (cur != null) {
                val startStr = epgTimeFmt.format(java.util.Date(cur.start))
                val endStr = epgTimeFmt.format(java.util.Date(cur.end))
                map[ch.id] = "▶ ${cur.title}  [$startStr-$endStr]"
            }
        }
        return map
    }

    /** 构建每个频道的下一个节目文本：channelId -> "下一个：xxx [HH:mm-HH:mm]" */
    private fun buildEpgNextMap(): Map<String, String> {
        val now = System.currentTimeMillis()
        val map = HashMap<String, String>()
        for (ch in allChannels) {
            val programs = epgPrograms[ch.id] ?: continue
            val next = programs.firstOrNull { it.start >= now }
            if (next != null) {
                val startStr = epgTimeFmt.format(java.util.Date(next.start))
                val endStr = epgTimeFmt.format(java.util.Date(next.end))
                map[ch.id] = "◷ ${next.title}  [$startStr-$endStr]"
            }
        }
        return map
    }

    /** 更新右侧节目详情栏（EPG 当前节目+进度+描述+今日节目单）。ch 为空时用当前播放频道。 */
    private fun updateProgramInfo(ch: Channel? = null) {
        try {
            val target = ch ?: currentChannel
            if (target == null) {
                binding.tvInfoChannel.text = "未选择频道"
                binding.tvInfoNow.text = "请先选择频道"
                binding.tvInfoNowTime.text = ""
                binding.infoProgressBar.visibility = View.GONE
                binding.tvInfoDesc.text = ""
                epgListAdapter.submitPrograms(emptyList(), null)
                binding.tvInfoMeta.text = ""
                return
            }
            binding.tvInfoChannel.text = target.name
            val programs = epgPrograms[target.id] ?: emptyList()
            val now = System.currentTimeMillis()
            val current = programs.firstOrNull { now in it.start until it.end }
            if (current != null) {
                binding.tvInfoNow.text = current.title
                val startStr = formatTime(current.start)
                val endStr = formatTime(current.end)
                val remainingMin = ((current.end - now) / 60000).toInt()
                val remainingStr = if (remainingMin > 0) "剩余${remainingMin}分钟" else "即将结束"
                binding.tvInfoNowTime.text = "$startStr-$endStr · $remainingStr"
                // 进度条
                val duration = current.end - current.start
                if (duration > 0) {
                    val progress = ((now - current.start) * 100 / duration).toInt().coerceIn(0, 100)
                    binding.infoProgressBar.progress = progress
                    binding.infoProgressBar.visibility = View.VISIBLE
                } else {
                    binding.infoProgressBar.visibility = View.GONE
                }
                // 节目描述
                binding.tvInfoDesc.text = if (current.description.isNotEmpty()) current.description else ""
            } else {
                binding.tvInfoNow.text = when (epgLoadState) {
                    EpgLoadState.NOT_CONFIGURED -> "暂无节目单（请在设置中添加节目指南）"
                    EpgLoadState.LOADING -> "节目指南加载中…"
                    EpgLoadState.FAILED -> "节目指南加载失败"
                    EpgLoadState.READY -> "该时段暂无节目"
                }
                binding.tvInfoNowTime.text = ""
                binding.infoProgressBar.visibility = View.GONE
                binding.tvInfoDesc.text = ""
            }
            // 今日节目单：从当前时间开始，取接下来 12 个节目
            val upcoming = programs.filter { it.end >= now }.take(12)
            epgListAdapter.submitPrograms(upcoming, current?.start)
            // 元信息：分组 + 线路数
            val lineCount = playback.sourceCount()
            binding.tvInfoMeta.text = (target.group ?: "") + if (lineCount > 1) " · ${lineCount}条线路" else ""
        } catch (ignored: Throwable) {
        }
    }

    private fun updateNowPlaying() {
        try {
            val ch = currentChannel
            if (ch == null) {
                binding.tvChannelName.text = getString(R.string.no_channels)
                binding.tvEpgNow.text = getString(R.string.no_epg)
                binding.tvEpgNext.text = ""
                binding.tvChannelMeta.text = ""
                return
            }
            binding.tvChannelName.maxLines = 1
            binding.tvChannelName.text = ch.name

            // 序号 / 总数 + 分辨率 + 线路（多线路频道）
            val idx = allChannels.indexOfFirst { it.id == ch.id }
            val meta = StringBuilder()
            if (idx >= 0) {
                meta.append("第 ").append(idx + 1).append(" / ").append(allChannels.size).append(" 频道")
            }
            val srcCount = playback.sourceCount()
            if (srcCount > 1) {
                if (meta.isNotEmpty()) meta.append(" · ")
                meta.append(getString(R.string.line_fmt, playback.currentSourceIndex() + 1, srcCount))
            }
            if (videoW > 0 && videoH > 0) {
                if (meta.isNotEmpty()) meta.append(" · ")
                meta.append("分辨率 ").append(videoW).append("×").append(videoH)
            }
            binding.tvChannelMeta.text = meta.toString()

            val programs = epgPrograms[ch.id] ?: emptyList()
            val now = System.currentTimeMillis()
            val current = programs.firstOrNull { now in it.start until it.end }
            val next = programs.firstOrNull { it.start >= now }
            if (current != null) {
                val startStr = formatTime(current.start)
                val endStr = formatTime(current.end)
                val remainingMin = ((current.end - now) / 60000).toInt()
                val remainingStr = if (remainingMin > 0) "剩余 ${remainingMin} 分钟" else "即将结束"
                binding.tvEpgNow.text = "正在播放: ${current.title}  [$startStr-$endStr]  $remainingStr"
                // 进度条
                val duration = current.end - current.start
                if (duration > 0) {
                    val progress = ((now - current.start) * 100 / duration).toInt().coerceIn(0, 100)
                    binding.epgProgressBar.progress = progress
                    binding.epgProgressBar.visibility = View.VISIBLE
                } else {
                    binding.epgProgressBar.visibility = View.GONE
                }
            } else {
                binding.tvEpgNow.text = getString(R.string.no_epg)
                binding.epgProgressBar.visibility = View.GONE
            }
            binding.tvEpgNext.text =
                if (next != null) "稍后 ${formatTime(next.start)}-${formatTime(next.end)}  ${next.title}" else ""
            updateFavoriteIcon()
        } catch (ignored: Throwable) {
        }
    }

    /** 仅更新 EPG 进度条（每秒调用，不更新文字，避免频繁重绘） */
    private fun updateEpgProgressOnly() {
        try {
            val now = System.currentTimeMillis()
            // 顶部信息栏进度条（当前播放频道）
            val ch = currentChannel
            if (ch != null) {
                val programs = epgPrograms[ch.id]
                if (programs != null) {
                    val current = programs.firstOrNull { now in it.start until it.end }
                    if (current != null) {
                        val duration = current.end - current.start
                        if (duration > 0) {
                            val progress = ((now - current.start) * 100 / duration).toInt().coerceIn(0, 100)
                            binding.epgProgressBar.progress = progress
                            binding.epgProgressBar.visibility = View.VISIBLE
                        }
                    } else {
                        binding.epgProgressBar.visibility = View.GONE
                    }
                }
            }
            // 第三栏节目详情进度条（当前焦点频道，频道列表可见时才更新）
            if (binding.channelPanel.visibility == View.VISIBLE) {
                val focusCh = lastFocusedChannel ?: currentChannel
                if (focusCh != null) {
                    val focusPrograms = epgPrograms[focusCh.id]
                    if (focusPrograms != null) {
                        val focusCurrent = focusPrograms.firstOrNull { now in it.start until it.end }
                        if (focusCurrent != null) {
                            val fduration = focusCurrent.end - focusCurrent.start
                            if (fduration > 0) {
                                val fprogress = ((now - focusCurrent.start) * 100 / fduration).toInt().coerceIn(0, 100)
                                binding.infoProgressBar.progress = fprogress
                                binding.infoProgressBar.visibility = View.VISIBLE
                            }
                        }
                    }
                }
            }
        } catch (ignored: Throwable) {
        }
    }

    private fun updateClockVisibility() {
        // 显示时间偏好：false 时右上角不再显示时钟（网速行也随时钟一起隐藏）
        binding.tvClock.visibility = if (repository.showClock) View.VISIBLE else View.GONE
    }

    private fun formatTime(ts: Long): String {
        return SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ts))
    }

    // ---------- PlaybackManager.Listener ----------

    override fun onPlaybackReady(channelName: String) {
        try {
            binding.tvChannelName.text = channelName
            updateNowPlaying()
        } catch (ignored: Throwable) {
        }
    }

    override fun onPlaybackError(message: String) {
        try {
            val srcCount = playback.sourceCount()
            binding.tvEpgNow.text =
                if (srcCount > 1) {
                    "线路 ${playback.currentSourceIndex() + 1}/$srcCount: $message"
                } else {
                    "播放失败: $message"
                }
        } catch (ignored: Throwable) {
        }
    }

    override fun onPlaybackStateChanged(isPlaying: Boolean) {
        // 直播无播放/暂停按钮，此回调预留
    }

    override fun onVideoSizeChanged(width: Int, height: Int) {
        try {
            videoW = width
            videoH = height
            updateNowPlaying()
        } catch (ignored: Throwable) {
        }
    }

    // ---------- 遥控器按键 ----------

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // 设置面板打开：返回键逐层退出（详情 → 导航列 → 关闭）；
        // 菜单/设置键与全屏态打开它的按键对应，直接关闭；OK 从导航列进入详情
        if (isSettingsPanelVisible) {
            val settingNavs = settingsNavs()
            val navFocused = settingNavs.any { it.hasFocus() }
            val detailFocused = settingsSections().any { s -> containsFocus(s) }
            return when (keyCode) {
                KeyEvent.KEYCODE_BACK -> {
                    if (detailFocused) {
                        settingNavs[currentSettingsTab.coerceIn(0, settingNavs.lastIndex)].requestFocus()
                    } else {
                        hideSettingsPanel()
                    }
                    true
                }
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS -> {
                    hideSettingsPanel(); true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    // 焦点在导航列 -> 进入详情区并定位到当前值；详情区最右侧不再跳去「关闭」
                    when {
                        navFocused -> {
                            focusValueInSettingsSection(currentSettingsTab)
                            true
                        }
                        detailFocused && !settingsDetailHasNeighbor(horizontal = true, forward = true) -> true
                        else -> super.onKeyDown(keyCode, event)
                    }
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    // 详情区最左侧 -> 回到导航列当前项；同一行的多个选项之间仍可左右移动
                    when {
                        detailFocused && !settingsDetailHasNeighbor(horizontal = true, forward = false) -> {
                            settingNavs[currentSettingsTab.coerceIn(0, settingNavs.lastIndex)].requestFocus()
                            true
                        }
                        else -> super.onKeyDown(keyCode, event)
                    }
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    // OK 进详情；「退出」项保持默认点击（弹确认框）
                    if (navFocused && !binding.navExit.hasFocus()) {
                        focusValueInSettingsSection(currentSettingsTab)
                        true
                    } else {
                        super.onKeyDown(keyCode, event)
                    }
                }
                KeyEvent.KEYCODE_DPAD_UP -> {
                    // 详情区到顶回导航列当前项；导航列到顶去「关闭」按钮；
                    // 不让 FocusFinder 自己找最近控件，否则会跳到相邻分类上
                    when {
                        detailFocused && !settingsDetailHasNeighbor(horizontal = false, forward = false) -> {
                            focusSettingsNavCurrent(); true
                        }
                        navFocused && binding.navLineup.hasFocus() -> {
                            binding.btnCloseSettings.requestFocus(); true
                        }
                        binding.btnCloseSettings.hasFocus() -> true
                        else -> super.onKeyDown(keyCode, event)
                    }
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    when {
                        detailFocused && !settingsDetailHasNeighbor(horizontal = false, forward = true) -> true
                        binding.btnCloseSettings.hasFocus() -> {
                            focusSettingsNavCurrent(); true
                        }
                        navFocused && binding.navExit.hasFocus() -> true
                        else -> super.onKeyDown(keyCode, event)
                    }
                }
                else -> super.onKeyDown(keyCode, event)
            }
        }
        // 频道列表打开：BACK 关闭；左右键在分组/频道间切换焦点
        if (isChannelPanelVisible) {
            if (binding.tvSourceBar.hasFocus()) {
                return when (keyCode) {
                    KeyEvent.KEYCODE_BACK -> {
                        hideChannelPanel(); true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        switchToNextSource(); true
                    }
                    else -> super.onKeyDown(keyCode, event)
                }
            }
            // 工具条：搜索框与三个按钮之间必须能左右移动，否则遥控器够不到设置
            val toolbarButtons = listOf(
                binding.btnFavoriteFocused, binding.btnFavorites, binding.btnPanelSettings
            )
            if (binding.searchInput.hasFocus()) {
                return when (keyCode) {
                    KeyEvent.KEYCODE_BACK -> {
                        hideChannelPanel(); true
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        binding.tvSourceBar.requestFocus(); true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        binding.channelList.requestFocus(); true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        // 光标在末尾时右移进入工具按钮，否则继续在文字间移动
                        if (binding.searchInput.selectionEnd == binding.searchInput.text.length) {
                            binding.btnFavoriteFocused.requestFocus(); true
                        } else {
                            super.onKeyDown(keyCode, event)
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        if (binding.searchInput.selectionStart > 0) {
                            super.onKeyDown(keyCode, event)
                        } else {
                            true
                        }
                    }
                    else -> super.onKeyDown(keyCode, event)
                }
            }
            if (toolbarButtons.any { it.hasFocus() }) {
                return when (keyCode) {
                    KeyEvent.KEYCODE_BACK -> {
                        hideChannelPanel(); true
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        binding.tvSourceBar.requestFocus(); true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        binding.channelList.requestFocus(); true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        val i = toolbarButtons.indexOfFirst { it.hasFocus() }
                        if (i > 0) toolbarButtons[i - 1].requestFocus()
                        else binding.searchInput.requestFocus()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        val i = toolbarButtons.indexOfFirst { it.hasFocus() }
                        if (i in 0 until toolbarButtons.lastIndex) toolbarButtons[i + 1].requestFocus()
                        true
                    }
                    else -> super.onKeyDown(keyCode, event)
                }
            }
            return when (keyCode) {
                KeyEvent.KEYCODE_BACK -> {
                    hideChannelPanel(); true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    // 左移：如果焦点在频道列表，切到分组列表
                    if (binding.channelList.hasFocus() || binding.programInfo.hasFocus()) {
                        binding.groupList.requestFocus()
                    }
                    true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    // 右移：焦点在分组列表 → 滚动定位到目标频道 → 请求右栏焦点
                    if (binding.groupList.hasFocus()) {
                        val targetPos = if (pendingChannelScrollPos >= 0) {
                            pendingChannelScrollPos
                        } else {
                            currentChannel?.let { adapter.positionOfChannel(it.id) }
                                ?.takeIf { it >= 0 }
                                ?: adapter.firstPositionOfGroup(currentGroup ?: "")
                        }
                        if (targetPos >= 0) {
                            scrollChannelListTo(targetPos)
                        }
                        pendingChannelScrollPos = -1
                        binding.channelList.post {
                            if (targetPos >= 0) {
                                // 再延迟一帧等布局完成，否则未布局的行 findViewHolder 返回 null
                                binding.channelList.post {
                                    val holder = binding.channelList.findViewHolderForAdapterPosition(targetPos)
                                    holder?.itemView?.requestFocus()
                                }
                            }
                            if (!binding.channelList.hasFocus()) binding.channelList.requestFocus()
                        }
                    }
                    true
                }
                KeyEvent.KEYCODE_MENU -> {
                    // 频道列表有焦点：菜单键 = 收藏/取消收藏当前焦点频道；
                    // 焦点在分组/来源栏时：进入设置（无设置按钮的遥控器也能用）
                    if (binding.channelList.hasFocus()) {
                        toggleFavoriteFocused()
                    } else {
                        showSettingsPanel()
                    }
                    true
                }
                // 部分遥控器把设置键映射成 KEYCODE_SETTINGS
                KeyEvent.KEYCODE_SETTINGS -> {
                    showSettingsPanel(); true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    // 频道列表有焦点：OK 立即播放焦点频道并关闭列表（已实时预览则直接关闭）
                    // 分组列表有焦点：OK 进入频道列表
                    if (binding.channelList.hasFocus()) {
                        lastFocusedChannel?.let { ch ->
                            if (currentChannel?.id != ch.id) {
                                currentChannel = ch
                                repository.lastChannelId = ch.id
                                adapter.setSelected(ch.id)
                                playback.play(ch.sources.ifEmpty { listOf(ch.url) }, ch.name)
                                updateNowPlaying()
                            }
                        }
                        hideChannelPanel()
                    } else if (binding.groupList.hasFocus()) {
                        binding.channelList.requestFocus()
                    } else {
                        super.onKeyDown(keyCode, event)
                    }
                    true
                }
                else -> super.onKeyDown(keyCode, event)
            }
        }
        // 全屏播放态：任何按键都重新显示覆盖层并重置自动隐藏计时
        showOverlay()
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                switchToPrevLine(); true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                switchToNextLine(); true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                switchChannel(-1); true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                switchChannel(1); true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                showChannelPanel(); true
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS -> {
                showSettingsPanel(); true
            }
            // 收藏键：遥控器上的「信息/收藏」键直接收藏当前播放的频道
            // （播放界面控制条已隐藏，这是全屏态下唯一的一键收藏入口）
            KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_BOOKMARK -> {
                toggleFavoriteCurrent(); true
            }
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                switchChannel(1); true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                switchChannel(-1); true
            }
            KeyEvent.KEYCODE_BACK -> {
                // 双击返回退出
                val now = System.currentTimeMillis()
                if (now - lastBackPressTime < 2000) {
                    showExitDialog()
                } else {
                    lastBackPressTime = now
                    Toast.makeText(applicationContext, "再按一次返回键退出", Toast.LENGTH_SHORT).show()
                }
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    /** 退出确认弹窗 */
    private fun showExitDialog() {
        try {
            AlertDialog.Builder(this)
                .setTitle("退出揽星TV")
                .setMessage("确定要退出应用吗？")
                .setPositiveButton("退出") { _, _ ->
                    finishAffinity()
                    android.os.Process.killProcess(android.os.Process.myPid())
                }
                .setNegativeButton("取消", null)
                .show()
        } catch (ignored: Throwable) {
        }
    }

    override fun onDestroy() {
        overlayHandler.removeCallbacksAndMessages(null)
        clockHandler.removeCallbacksAndMessages(null)
        // 换台防抖任务必须撤销：Activity 销毁 260ms 后仍可能触发换台并访问已 release 的播放器。
        switchHandler.removeCallbacksAndMessages(null)
        previewHandler.removeCallbacksAndMessages(null)
        surfaceResumeHandler.removeCallbacksAndMessages(null)
        sleepTimerHandler.removeCallbacksAndMessages(null)
        try {
            remoteServer?.stop()
        } catch (ignored: Exception) {
        }
        // 修复：必须在 super.onDestroy() 之前释放播放器，
        // 否则 Activity 已销毁后再 release() 可能异常或资源泄漏。
        try {
            // 修复：正常销毁（覆盖安装/系统回收）时关闭测速线程池，
            // 避免 3 个测速线程常驻泄漏（此前只在 exitApp 退出时 shutdown）。
            sourceHealthChecker.shutdown()
        } catch (ignored: Exception) {
        }
        try {
            playback.release()
        } catch (ignored: Exception) {
        }
        super.onDestroy()
    }

    // ---------- 左侧分组列表 Adapter ----------

    private inner class GroupAdapter(
        private val onGroupClick: (String?) -> Unit,
        private val onGroupFocused: (String?) -> Unit = {}
    ) : RecyclerView.Adapter<GroupAdapter.VH>() {

        private var groups: List<String?> = emptyList()
        private var selected: String? = null

        fun submitGroups(newGroups: List<String?>) {
            groups = newGroups
            notifyDataSetChanged()
        }

        fun setSelected(group: String?) {
            selected = group
            notifyDataSetChanged()
        }

        fun positionOfGroup(group: String?): Int {
            return groups.indexOfFirst { (it == null && group == null) || it == group }
        }

        inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val tvName: TextView = itemView.findViewById(android.R.id.text1)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val tv = TextView(parent.context).apply {
                id = android.R.id.text1
                layoutParams = RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT,
                    RecyclerView.LayoutParams.WRAP_CONTENT
                )
                setPadding(48, 36, 24, 36)
                setTextColor(0xFFCCCCCC.toInt())
                textSize = 16f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = android.view.Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                // 阻止系统自动焦点搜索：右键交给 Activity.onKeyDown 处理（定位到当前频道）
                nextFocusRightId = View.NO_ID
            }
            return VH(tv)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val group = groups[position]
            holder.tvName.text = group ?: "全部"
            val isSelected = (selected == null && group == null) || selected == group
            // 选中样式：蓝字（无背景），与焦点亮蓝背景区分
            holder.tvName.setBackgroundColor(0x00000000)
            holder.tvName.setTextColor(
                if (isSelected) 0xFF3D8BFF.toInt() else 0xFFCCCCCC.toInt()
            )
            holder.tvName.paint.isFakeBoldText = isSelected
            // 焦点样式：圆角亮蓝背景 + 白字加粗；焦点移动即切换分组（无需 OK）
            holder.tvName.onFocusChangeListener = View.OnFocusChangeListener { _, focused ->
                if (focused) {
                    holder.tvName.setBackgroundResource(R.drawable.bg_item_focused)
                    holder.tvName.setTextColor(0xFFFFFFFF.toInt())
                    holder.tvName.paint.isFakeBoldText = true
                    onGroupFocused(group)
                } else {
                    holder.tvName.setBackgroundResource(0)
                    holder.tvName.setTextColor(
                        if (isSelected) 0xFF3D8BFF.toInt() else 0xFFCCCCCC.toInt()
                    )
                    holder.tvName.paint.isFakeBoldText = isSelected
                }
            }
            holder.itemView.setOnClickListener { onGroupClick(group) }
        }

        override fun getItemCount() = groups.size
    }
}