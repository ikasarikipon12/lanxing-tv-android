package com.cyj265.iptvplayer.data

import java.util.regex.Pattern
import org.json.JSONObject

/**
 * 自动识别并解析 M3U / M3U8、JSON API 或 TXT 播放列表。
 *
 * v1.7.1 起：解析完成后按（分组, 频道名）合并同名单频道为多线路，
 * 播放列表里重复出现的同名频道（如多个 CCTV1 源）只显示一个条目。
 */
object PlaylistParser {

    private val EXTINF_PATTERN = Pattern.compile(
        "#EXTINF:([^,]*),(.*)"
    )

    /**
     * 从 M3U 内容中提取 #EXTM3U 头部的 url-tvg="..." 属性（EPG 节目单地址）。
     * 支持多个 url-tvg（空格分隔）；返回去重后的地址列表，找不到返回空列表。
     */
    fun extractEpgUrls(content: String): List<String> {
        try {
            for (rawLine in content.split("\n", "\r\n")) {
                val line = rawLine.trim()
                if (!line.startsWith("#EXTM3U")) continue
                val urls = LinkedHashSet<String>()
                val m = Pattern.compile("url-tvg\\s*=\\s*\"([^\"]*)\"").matcher(line)
                while (m.find()) {
                    val value = m.group(1)?.trim() ?: ""
                    if (value.isNotEmpty() && value.startsWith("http")) urls.add(value)
                }
                return urls.toList()
            }
        } catch (ignored: Exception) {
        }
        return emptyList()
    }

    fun parseAuto(content: String): List<Channel> {
        // JSON API playlist (categories + channels) is supported alongside M3U/TXT.
        // Strip an optional UTF-8 BOM before detecting the payload format.
        val normalized = content.removePrefix("\uFEFF")
        val trimmed = normalized.trimStart()
        val raw = when {
            trimmed.startsWith("{") -> parseJsonRaw(normalized)
            trimmed.startsWith("#EXTM3U") || trimmed.startsWith("#EXTINF") -> parseRaw(normalized)
            else -> parseTxtRaw(normalized)
        }
        return mergeChannels(raw)
    }

    /**
     * Parse the JSON shape returned by the user's playlist endpoint:
     * { "categories": [{"id": 0, "name": "TV"}],
     *   "channels": [{"cid": 0, "name": "Channel", "stream_url": "https://..."}] }
     * The category id is resolved to its display name and used as the channel group.
     */
    private fun parseJsonRaw(content: String): List<Channel> {
        return try {
            val root = JSONObject(content.trim().removePrefix("\uFEFF"))
            val categoryNames = HashMap<String, String>()
            val categories = root.optJSONArray("categories")
            if (categories != null) {
                for (i in 0 until categories.length()) {
                    val category = categories.optJSONObject(i) ?: continue
                    val id = category.optString("id", "").trim()
                    val name = category.optString("name", "").trim()
                    if (id.isNotEmpty() && name.isNotEmpty()) {
                        categoryNames[id] = name
                    }
                }
            }

            val items = root.optJSONArray("channels") ?: return emptyList()
            val channels = ArrayList<Channel>(items.length())
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val categoryId = item.optString("cid", "").trim()
                val name = item.optString("name", "").trim()
                val url = item.optString("stream_url", "").trim()
                if (name.isEmpty() || !(url.startsWith("http://") || url.startsWith("https://"))) {
                    continue
                }
                val group = categoryNames[categoryId]?.takeIf { it.isNotBlank() } ?: "未分组"
                channels.add(
                    Channel(
                        id = "json-$categoryId-$i-${url.hashCode()}",
                        name = name,
                        url = url,
                        group = group,
                        logo = "",
                        tvgId = name,
                        sources = listOf(url)
                    )
                )
            }
            channels
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * 解析 TXT 播放列表。常见格式：
     *  频道名,http://...
     *  频道名，http://...（中文逗号）
     *  纯 URL 行（自动用序号命名）
     */
    private fun parseTxtRaw(content: String): List<Channel> {
        val channels = ArrayList<Channel>()
        var index = 0
        for (raw in content.split("\n", "\r\n")) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue

            var name: String
            var url: String

            val enIdx = line.lastIndexOf(',')
            val cnIdx = line.lastIndexOf('，')
            val sepIdx = if (cnIdx > enIdx) cnIdx else enIdx

            if (sepIdx > 0) {
                name = line.substring(0, sepIdx).trim()
                url = line.substring(sepIdx + 1).trim()
                if (!url.startsWith("http")) {
                    // 分隔符右边不是 URL，可能是 "url,name" 格式
                    val u = name
                    val n = url
                    if (u.startsWith("http")) {
                        name = if (n.isEmpty()) "频道 ${index + 1}" else n
                        url = u
                    } else {
                        continue
                    }
                }
            } else if (line.startsWith("http")) {
                url = line
                name = "频道 ${index + 1}"
            } else {
                // 尝试空格/Tab 分隔：name url
                // 【修复】不能用第一个空格/制表符切分：频道名本身常含空格
                // （如 "CCTV5+ 体育"、"凤凰卫视 中文台"），会被误当成分隔符，
                // 导致整行被丢弃。改为定位行内第一个 http(s):// 的位置：
                // 其前为频道名，其后为 URL（从 http 起点取，保留完整协议头）。
                var httpIdx = line.indexOf("http://")
                if (httpIdx < 0) httpIdx = line.indexOf("https://")
                if (httpIdx > 0) {
                    name = line.substring(0, httpIdx).trim()
                    url = line.substring(httpIdx).trim()
                } else {
                    continue
                }
            }

            if (!url.startsWith("http")) continue
            if (name.isEmpty()) name = "频道 ${index + 1}"

            channels.add(
                Channel.from(
                    m3uIndex = index++,
                    name = name,
                    url = url,
                    group = "本地列表",
                    logo = "",
                    tvgId = name
                )
            )
        }
        return channels
    }

    private fun parseRaw(content: String): List<Channel> {
        val channels = ArrayList<Channel>()
        val lines = content.split("\n", "\r\n")
        var pendingName = ""
        var pendingGroup = ""
        var pendingLogo = ""
        var pendingTvgId = ""
        var pendingUrls = ArrayList<String>()
        var index = 0

        fun flushPending() {
            if (pendingName.isNotEmpty() && pendingUrls.isNotEmpty()) {
                val tvgId = if (pendingTvgId.isEmpty()) pendingName else pendingTvgId
                channels.add(
                    Channel(
                        id = "ch-$index-${pendingUrls[0].hashCode()}",
                        name = pendingName,
                        url = pendingUrls[0],
                        group = if (pendingGroup.isEmpty()) "未分组" else pendingGroup,
                        logo = pendingLogo,
                        tvgId = tvgId,
                        sources = pendingUrls.toList()
                    )
                )
                index++
            }
            pendingName = ""
            pendingGroup = ""
            pendingLogo = ""
            pendingTvgId = ""
            pendingUrls = ArrayList()
        }

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue

            if (line.startsWith("#EXTINF")) {
                // 新频道开始：先 flush 上一个频道的所有线路
                flushPending()
                val m = EXTINF_PATTERN.matcher(line)
                if (m.matches()) {
                    val attrs = m.group(1) ?: ""
                    pendingName = m.group(2) ?: ""
                    pendingGroup = extractAttr(attrs, "group-title")
                    pendingLogo = extractAttr(attrs, "tvg-logo")
                    pendingTvgId = extractAttr(attrs, "tvg-id")
                }
            } else if (!line.startsWith("#")) {
                // 频道流地址：收集到当前频道的线路列表（支持连续多个URL）
                if (pendingName.isNotEmpty() && line.startsWith("http")) {
                    if (!pendingUrls.contains(line)) pendingUrls.add(line)
                }
            }
            // 其他 # 开头的行（#EXTM3U / #EXTVLCOPT 等）直接忽略
        }
        // flush 最后一个频道
        flushPending()
        return channels
    }

    /**
     * 按（分组, 频道名）合并同名单频道，URL 列表按出现顺序保留，
     * 并生成稳定的频道 id（基于分组+名称），保证收藏/缓存跨版本可用。
     */
    private fun mergeChannels(raw: List<Channel>): List<Channel> {
        if (raw.isEmpty()) return raw
        val urlsByKey = LinkedHashMap<Pair<String, String>, MutableList<String>>()
        val metaByKey = LinkedHashMap<Pair<String, String>, Channel>()

        for (c in raw) {
            val key = c.group to c.name
            val urls = urlsByKey.getOrPut(key) { ArrayList() }
            // 关键修复：合并时要把 c.sources（多线路）全部收集，不能只取 c.url
            val srcList = if (c.sources.isEmpty()) listOf(c.url) else c.sources
            for (s in srcList) {
                if (!urls.contains(s)) urls.add(s)
            }
            if (!metaByKey.containsKey(key)) metaByKey[key] = c
        }

        val out = ArrayList<Channel>(urlsByKey.size)
        for ((key, urls) in urlsByKey) {
            val base = metaByKey[key] ?: continue
            val stableId = "ch-" + key.first.hashCode().toString(16) + "-" + key.second.hashCode().toString(16)
            out.add(
                Channel(
                    id = stableId,
                    name = key.second,
                    url = urls[0],
                    group = key.first,
                    logo = base.logo,
                    tvgId = base.tvgId,
                    sources = urls.toList()
                )
            )
        }
        return out
    }

    private fun extractAttr(attrText: String, key: String): String {
        val pattern = Pattern.compile("$key\\s*=\\s*\"([^\"]*)\"")
        val m = pattern.matcher(attrText)
        return if (m.find()) m.group(1) else ""
    }
}
